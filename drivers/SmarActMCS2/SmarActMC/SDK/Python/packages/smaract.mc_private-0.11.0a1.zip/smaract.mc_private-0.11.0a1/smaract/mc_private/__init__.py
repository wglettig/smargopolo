#######################################################################
# Copyright (c) 2020 SmarAct GmbH
#
# THIS  SOFTWARE, DOCUMENTS, FILES AND INFORMATION ARE PROVIDED 'AS IS'
# WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
# BUT  NOT  LIMITED  TO, THE  IMPLIED  WARRANTIES  OF MERCHANTABILITY,
# FITNESS FOR A PURPOSE, OR THE WARRANTY OF NON - INFRINGEMENT.
# THE  ENTIRE  RISK  ARISING OUT OF USE OR PERFORMANCE OF THIS SOFTWARE
# REMAINS WITH YOU.
# IN  NO  EVENT  SHALL  THE  SMARACT  GMBH  BE  LIABLE  FOR ANY DIRECT,
# INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL OR OTHER DAMAGES ARISING
# OUT OF THE USE OR INABILITY TO USE THIS SOFTWARE.
#
# Generated on 2020-05-18 17:14 +0200
#

"""
Python bindings for SmarActMC
(C) SmarAct GmbH
Refer to the SmarAct EULA for licensing
SmarAct Motion Control Python API (Private)
"""

from cffi import FFI
import enum
import sys
assert sys.version_info >= (3, 4), "Python v3.4 or higher is required"
apigen_version = (1, 3, 5)
api_version = (0, 11, 0)
def __initBindings(libName):
    global ffi, lib
    ffi = FFI()
    ffi.cdef("""
typedef unsigned int uint32_t;
typedef uint32_t SA_MC_PropertyKey;
struct SA_MC_Vec3{ double x; double y; double z;};
typedef struct SA_MC_Vec3 SA_MC_Vec3;
struct SA_MC_Pose{ double x; double y; double z; double rx; double ry; double rz;};
typedef struct SA_MC_Pose SA_MC_Pose;
typedef uint32_t SA_MC_Handle;
typedef int int32_t;
typedef int32_t SA_MC_Result;
typedef unsigned long long size_t;
typedef unsigned char uint8_t;
typedef long long int64_t;
struct SA_MC_Event{ uint32_t type; uint8_t unused[28]; union { int32_t i32; int64_t i64; uint8_t reserved[32];};};
typedef struct SA_MC_Event SA_MC_Event;
SA_MC_Result SA_MC_GetResultInfo(SA_MC_Result resultCode, char const **info);
SA_MC_Result SA_MC_FindControllers(char const *options, char *outBuffer, size_t *bufferSize);
SA_MC_Result SA_MC_Open(SA_MC_Handle *outHandle, char const *options);
SA_MC_Result SA_MC_Close(SA_MC_Handle handle);
SA_MC_Result SA_MC_Reference(SA_MC_Handle handle);
SA_MC_Result SA_MC_Move(SA_MC_Handle handle, SA_MC_Pose const *pose);
SA_MC_Result SA_MC_WaitForEvent(SA_MC_Handle handle, SA_MC_Event *outEvent, int32_t timeout);
SA_MC_Result SA_MC_Stop(SA_MC_Handle handle);
SA_MC_Result SA_MC_Cancel(SA_MC_Handle handle);
SA_MC_Result SA_MC_GetPose(SA_MC_Handle handle, SA_MC_Pose *pose);
SA_MC_Result SA_MC_SetPivot(SA_MC_Handle handle, SA_MC_Vec3 const *pivot);
SA_MC_Result SA_MC_GetPivot(SA_MC_Handle handle, SA_MC_Vec3 *pivot);
SA_MC_Result SA_MC_SetProperty_i32(SA_MC_Handle handle, SA_MC_PropertyKey pkey, int32_t value);
SA_MC_Result SA_MC_SetProperty_f64(SA_MC_Handle handle, SA_MC_PropertyKey pkey, double value);
SA_MC_Result SA_MC_GetProperty_i32(SA_MC_Handle handle, SA_MC_PropertyKey pkey, int32_t *value);
SA_MC_Result SA_MC_GetProperty_f64(SA_MC_Handle handle, SA_MC_PropertyKey pkey, double *value);
SA_MC_Result SA_MC_GetProperty_s(SA_MC_Handle handle, SA_MC_PropertyKey pkey, char *outBuffer, size_t *bufferSize);
SA_MC_Result SA_MC_GetProperty_i32_a(SA_MC_Handle handle, SA_MC_PropertyKey pkey, int32_t *values, size_t *arraySize);
SA_MC_Result SA_MC_GetPropertyKey(SA_MC_Handle handle, char const *pname, SA_MC_PropertyKey *pkey);
SA_MC_Result SA_MC_AddFrame(SA_MC_Handle handle, uint32_t index, int32_t groupIndex, uint32_t type, char const *name, SA_MC_Pose const *trans, uint32_t enabled);
SA_MC_Result SA_MC_EditFrame(SA_MC_Handle handle, uint32_t index, int32_t groupIndex, uint32_t type, SA_MC_Pose const *trans, uint32_t enabled);
SA_MC_Result SA_MC_RemoveFrame(SA_MC_Handle handle, uint32_t index);
SA_MC_Result SA_MC_SetCurrentPoseAsZero(SA_MC_Handle handle);
SA_MC_Result SA_MC_GetFrame(SA_MC_Handle handle, uint32_t index, int32_t *outGroupIndex, uint32_t *outType, char const **outName, SA_MC_Pose *outTrans, uint32_t *outEnabled);
SA_MC_Result SA_MC_TransPose(SA_MC_Handle handle, SA_MC_Pose const *poseUD, SA_MC_Pose *outPoseRoot);
SA_MC_Result SA_MC_TransPoseInv(SA_MC_Handle handle, SA_MC_Pose const *poseRoot, SA_MC_Pose *outPoseUD);
SA_MC_Result SA_MC_TransPoint(SA_MC_Handle handle, SA_MC_Vec3 const *pointUD, SA_MC_Vec3 *outPointRoot);
SA_MC_Result SA_MC_TransPointInv(SA_MC_Handle handle, SA_MC_Vec3 const *pointRoot, SA_MC_Vec3 *outPointUD);
SA_MC_Result SA_MC_Calibrate(SA_MC_Handle handle);
""")
    lib = ffi.dlopen(libName)

class Error(Exception):
    def __init__(self, func, code, arguments):
        self.func = func
        self.code = code
        self.arguments = arguments
    def __str__(self):
        return "{} returned {} with arguments {}".format(self.func, self.code, self.arguments)
class Vec3:
    """
    Members:
     - x
     - y
     - z
    
    """
    __slots__ = ['x', 'y', 'z']
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z
    def asFFI(self):
        return ffi.new("struct SA_MC_Vec3 *", {'x': self.x, 'y': self.y, 'z': self.z})
class Pose:
    """
    Members:
     - x:  Translation parallel to the X axis [m] 
     - y:  Translation parallel to the Y axis [m] 
     - z:  Translation parallel to the Z axis [m] 
     - rx:  Rotation around the X axis in [deg]    
     - ry:  Rotation around the Y axis in [deg]    
     - rz:  Rotation around the Z axis in [deg]    
    
    """
    __slots__ = ['x', 'y', 'z', 'rx', 'ry', 'rz']
    def __init__(self, x, y, z, rx, ry, rz):
        self.x = x
        self.y = y
        self.z = z
        self.rx = rx
        self.ry = ry
        self.rz = rz
    def asFFI(self):
        return ffi.new("struct SA_MC_Pose *", {'x': self.x, 'y': self.y, 'z': self.z, 'rx': self.rx, 'ry': self.ry, 'rz': self.rz})
class Event:
    def __init__(self, inst):
        self.inst = inst
    def asFFI(self):
        return self.inst
    def __getattr__(self, attr):
        return getattr(self.inst, attr)
def GetResultInfo(resultCode):
    """
    Parameters:
     - resultCode: The result code.
    
    Return value(s):
     - info: A pointer to a C string.
    """
    local_0 = ffi.new("char const **")
    local_1 = lib.SA_MC_GetResultInfo(resultCode, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("GetResultInfo", local_1, {"resultCode": resultCode})
    return ffi.string(local_0[0]).decode()
def FindControllers(options = "", bufferSize = 256):
    """
    Parameters:
     - options = "": Reserved for now.
     - bufferSize = 256: Pass the size of the provided buffer in here, on
    return, it contains the number of characters returned in outBuffer,
     or the required size, if the supplied buffer was too small.
    
    Return value(s):
     - outBuffer: The buffer for writing the result string into. The
    locators of the found controllers are separated by by a newline
    character.
    """
    local_0 = ffi.new("char []", bufferSize)
    local_1 = ffi.new("size_t *", bufferSize)
    local_2 = lib.SA_MC_FindControllers(options.encode(), local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("FindControllers", local_2, {"options": options})
    return ffi.string(local_0, local_1[0]).decode()
def Open(options):
    """
    Parameters:
     - options: A list of options. each option must be defined on a new
    line. the format is  "[option value][option value]..."    possible
    options are: model   The device model code locator The locator of
    the axis controller. E.g. "network:192.168.1.200:5000" for network
    controllers or "usb:id:98765432" for controllers with USB
    interface. A network locator contains the IP address and the port
    of the controller. The USB locator format contains the first part
    of the MCS controller serial number.
    
    Return value(s):
     - outHandle: The generated handle is returned in *outHandle.
    """
    local_0 = ffi.new("SA_MC_Handle *")
    local_1 = lib.SA_MC_Open(local_0, options.encode())
    if local_1 != ErrorCode.NONE.value:
        raise Error("Open", local_1, {"options": options})
    return local_0[0]
def Close(handle):
    """
    Parameters:
     - handle: The device handle.
    """
    local_0 = lib.SA_MC_Close(handle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Close", local_0, {"handle": handle})
    return 
def Reference(handle):
    """
    Parameters:
     - handle: The device handle.
    """
    local_0 = lib.SA_MC_Reference(handle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Reference", local_0, {"handle": handle})
    return 
def Move(handle, pose):
    """
    Parameters:
     - handle: The device handle.
     - pose: The target pose.
    """
    local_0 = pose.asFFI()
    local_1 = lib.SA_MC_Move(handle, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("Move", local_1, {"handle": handle, "pose": pose})
    return 
def WaitForEvent(handle, timeout):
    """
    Parameters:
     - handle: The device handle.
     - timeout: Wait returns with a SA_MC_ERROR_TIMEOUT if the operations
    doesn't finish within timeout milliseconds. If timeout is
    
    Return value(s):
     - outEvent: The event data returned by the function.
    """
    local_0 = ffi.new("SA_MC_Event *")
    local_1 = lib.SA_MC_WaitForEvent(handle, local_0, timeout)
    if local_1 != ErrorCode.NONE.value:
        raise Error("WaitForEvent", local_1, {"handle": handle, "timeout": timeout})
    return Event(local_0)
def Stop(handle):
    """
    Parameters:
     - handle: The device handle.
    """
    local_0 = lib.SA_MC_Stop(handle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Stop", local_0, {"handle": handle})
    return 
def Cancel(handle):
    """
    Parameters:
     - handle: The device handle.
    """
    local_0 = lib.SA_MC_Cancel(handle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Cancel", local_0, {"handle": handle})
    return 
def GetPose(handle):
    """
    Parameters:
     - handle: The device handle.
    
    Return value(s):
     - pose: The returned pose.
    """
    local_0 = ffi.new("SA_MC_Pose *")
    local_1 = lib.SA_MC_GetPose(handle, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("GetPose", local_1, {"handle": handle})
    return Pose(local_0.x, local_0.y, local_0.z, local_0.rx, local_0.ry, local_0.rz)
def SetPivot(handle, pivot):
    """
    Parameters:
     - handle: The device handle.
     - pivot: The pivot point.
    """
    local_0 = pivot.asFFI()
    local_1 = lib.SA_MC_SetPivot(handle, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("SetPivot", local_1, {"handle": handle, "pivot": pivot})
    return 
def GetPivot(handle):
    """
    Parameters:
     - handle: The device handle.
    
    Return value(s):
     - pivot: The returned current pivot point.
    """
    local_0 = ffi.new("SA_MC_Vec3 *")
    local_1 = lib.SA_MC_GetPivot(handle, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("GetPivot", local_1, {"handle": handle})
    return Vec3(local_0.x, local_0.y, local_0.z)
def SetProperty_i32(handle, pkey, value):
    """
    Parameters:
     - handle: The device handle.
     - pkey: The property key.
     - value: The property value.
    """
    local_0 = lib.SA_MC_SetProperty_i32(handle, pkey, value)
    if local_0 != ErrorCode.NONE.value:
        raise Error("SetProperty_i32", local_0, {"handle": handle, "pkey": pkey, "value": value})
    return 
def SetProperty_f64(handle, pkey, value):
    """
    Parameters:
     - handle: The handle.
     - pkey: The property key.
     - value: The property value.
    """
    local_0 = lib.SA_MC_SetProperty_f64(handle, pkey, value)
    if local_0 != ErrorCode.NONE.value:
        raise Error("SetProperty_f64", local_0, {"handle": handle, "pkey": pkey, "value": value})
    return 
def GetProperty_i32(handle, pkey):
    """
    Parameters:
     - handle: The handle.
     - pkey: The property key.
    
    Return value(s):
     - value: The property value.
    """
    local_0 = ffi.new("int32_t *")
    local_1 = lib.SA_MC_GetProperty_i32(handle, pkey, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("GetProperty_i32", local_1, {"handle": handle, "pkey": pkey})
    return local_0[0]
def GetProperty_f64(handle, pkey):
    """
    Parameters:
     - handle: The handle.
     - pkey: The property key.
    
    Return value(s):
     - value: The property value.
    """
    local_0 = ffi.new("double *")
    local_1 = lib.SA_MC_GetProperty_f64(handle, pkey, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("GetProperty_f64", local_1, {"handle": handle, "pkey": pkey})
    return local_0[0]
def GetProperty_s(handle, pkey, bufferSize = 256):
    """
    Parameters:
     - handle: The handle.
     - pkey: The property key.
     - bufferSize = 256: In: the size of the buffer.  Out: the written
    number of characters +1 (for the string termination 0-byte)  if
    successful or the required buffer size, if not.
    
    Return value(s):
     - outBuffer: The buffer to write the string to.
    """
    local_0 = ffi.new("char []", bufferSize)
    local_1 = ffi.new("size_t *", bufferSize)
    local_2 = lib.SA_MC_GetProperty_s(handle, pkey, local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("GetProperty_s", local_2, {"handle": handle, "pkey": pkey})
    return ffi.string(local_0, local_1[0]).decode()
def GetProperty_i32_a(handle, pkey, arraySize = 1024):
    """
    Parameters:
     - handle: The handle.
     - pkey: The property key.
     - arraySize = 1024: In: the capacity of the buffer in number of
    elements,  Out: the number of returned elements or the required
    size.
    
    Return value(s):
     - values: The buffer supplied by the caller.
    """
    local_0 = ffi.new("int32_t []", arraySize)
    local_1 = ffi.new("size_t *", arraySize)
    local_2 = lib.SA_MC_GetProperty_i32_a(handle, pkey, local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("GetProperty_i32_a", local_2, {"handle": handle, "pkey": pkey})
    return ffi.unpack(local_0, local_1[0])
def GetPropertyKey(handle, pname):
    """
    Parameters:
     - handle: The handle.
     - pname: The property name.
    
    Return value(s):
     - pkey: The property key.
    """
    local_0 = ffi.new("SA_MC_PropertyKey *")
    local_1 = lib.SA_MC_GetPropertyKey(handle, pname.encode(), local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("GetPropertyKey", local_1, {"handle": handle, "pname": pname})
    return local_0[0]
def AddFrame(handle, index, groupIndex, type, name, trans, enabled):
    """
    Parameters:
     - handle: The device handle.
     - index: The zero-based index at which the transformation is inserted.
    
     - groupIndex: The group index.
     - type: The type of the transformation.
     - name: The name of the transformation.
     - trans: The coordinate transformation to add.
     - enabled: The added transformation is enabled if SA_MC_TRUE is passed
     and disabled for SA_MC_TRUE.
    """
    local_0 = trans.asFFI()
    local_1 = lib.SA_MC_AddFrame(handle, index, groupIndex, type, name.encode(), local_0, enabled)
    if local_1 != ErrorCode.NONE.value:
        raise Error("AddFrame", local_1, {"handle": handle, "index": index, "groupIndex": groupIndex, "type": type, "name": name, "trans": trans, "enabled": enabled})
    return 
def EditFrame(handle, index, groupIndex, type, trans, enabled):
    """
    Parameters:
     - handle: The device handle.
     - index: The zero-based index at which the transformation is edited.
     - groupIndex: The group index.
     - type: The type of the transformation.
     - trans: The edited coordinate transformation entry.
     - enabled: The added transformation is enabled if SA_MC_TRUE is passed
     and disabled for SA_MC_TRUE.
    """
    local_0 = trans.asFFI()
    local_1 = lib.SA_MC_EditFrame(handle, index, groupIndex, type, local_0, enabled)
    if local_1 != ErrorCode.NONE.value:
        raise Error("EditFrame", local_1, {"handle": handle, "index": index, "groupIndex": groupIndex, "type": type, "trans": trans, "enabled": enabled})
    return 
def RemoveFrame(handle, index):
    """
    Parameters:
     - handle: The device handle.
     - index: The index for the transformation to be removed.
    """
    local_0 = lib.SA_MC_RemoveFrame(handle, index)
    if local_0 != ErrorCode.NONE.value:
        raise Error("RemoveFrame", local_0, {"handle": handle, "index": index})
    return 
def SetCurrentPoseAsZero(handle):
    """
    Parameters:
     - handle: The device handle.
    """
    local_0 = lib.SA_MC_SetCurrentPoseAsZero(handle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("SetCurrentPoseAsZero", local_0, {"handle": handle})
    return 
def GetFrame(handle, index):
    """
    Parameters:
     - handle: The device handle.
     - index: The zero-based index of the transformation to get.
    
    Return value(s):
     - outGroupIndex: The group index of the transformation.
     - outType: The type of the transformation.
     - outName: The name of the transformation.
     - outTrans: The coordinate transformation.
     - outEnabled: The added transformation is enabled if SA_MC_TRUE is
    passed and disabled for SA_MC_TRUE.
    """
    local_0 = ffi.new("int32_t *")
    local_1 = ffi.new("uint32_t *")
    local_2 = ffi.new("char const **")
    local_3 = ffi.new("SA_MC_Pose *")
    local_4 = ffi.new("uint32_t *")
    local_5 = lib.SA_MC_GetFrame(handle, index, local_0, local_1, local_2, local_3, local_4)
    if local_5 != ErrorCode.NONE.value:
        raise Error("GetFrame", local_5, {"handle": handle, "index": index})
    return local_0[0], local_1[0], ffi.string(local_2[0]).decode(), Pose(local_3.x, local_3.y, local_3.z, local_3.rx, local_3.ry, local_3.rz), local_4[0]
def TransPose(handle, poseUD):
    """
    Parameters:
     - handle: The device handle.
     - poseUD: The input pose to be transformed.
    
    Return value(s):
     - outPoseRoot: The transformed output pose.
    """
    local_0 = poseUD.asFFI()
    local_1 = ffi.new("SA_MC_Pose *")
    local_2 = lib.SA_MC_TransPose(handle, local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("TransPose", local_2, {"handle": handle, "poseUD": poseUD})
    return Pose(local_1.x, local_1.y, local_1.z, local_1.rx, local_1.ry, local_1.rz)
def TransPoseInv(handle, poseRoot):
    """
    Parameters:
     - handle: The device handle.
     - poseRoot: The input pose to be transformed.
    
    Return value(s):
     - outPoseUD: The transformed output pose.
    """
    local_0 = poseRoot.asFFI()
    local_1 = ffi.new("SA_MC_Pose *")
    local_2 = lib.SA_MC_TransPoseInv(handle, local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("TransPoseInv", local_2, {"handle": handle, "poseRoot": poseRoot})
    return Pose(local_1.x, local_1.y, local_1.z, local_1.rx, local_1.ry, local_1.rz)
def TransPoint(handle, pointUD):
    """
    Parameters:
     - handle: The device handle.
     - pointUD: The input pose to be transformed.
    
    Return value(s):
     - outPointRoot: The transformed output pose.
    """
    local_0 = pointUD.asFFI()
    local_1 = ffi.new("SA_MC_Vec3 *")
    local_2 = lib.SA_MC_TransPoint(handle, local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("TransPoint", local_2, {"handle": handle, "pointUD": pointUD})
    return Vec3(local_1.x, local_1.y, local_1.z)
def TransPointInv(handle, pointRoot):
    """
    Parameters:
     - handle: The device handle.
     - pointRoot: The input pose to be transformed.
    
    Return value(s):
     - outPointUD: The transformed output pose.
    """
    local_0 = pointRoot.asFFI()
    local_1 = ffi.new("SA_MC_Vec3 *")
    local_2 = lib.SA_MC_TransPointInv(handle, local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("TransPointInv", local_2, {"handle": handle, "pointRoot": pointRoot})
    return Vec3(local_1.x, local_1.y, local_1.z)
def Calibrate(handle):
    """
    Parameters:
     - handle: The device handle.
    """
    local_0 = lib.SA_MC_Calibrate(handle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Calibrate", local_0, {"handle": handle})
    return 
class ApiVersion(enum.IntEnum):
    MAJOR  = 0x0
    MINOR  = 0xb
    UPDATE = 0x0
class ErrorCode(enum.IntEnum):
    NONE                          = 0x000
    OTHER                         = 0x001
    INVALID_PARAMETER             = 0x002
    INVALID_LOCATOR               = 0x003
    INVALID_HANDLE                = 0x005
    NOT_SUPPORTED                 = 0x006
    SOFTWARE_RESOURCE_LIMIT       = 0x007
    QUERYBUFFER_SIZE              = 0x008
    WRONG_DATA_TYPE               = 0x009
    NO_ACCESS                     = 0x00a
    INVALID_PROPERTY              = 0x020
    CANCELED                      = 0x100
    TIMEOUT                       = 0x101
    POSE_UNREACHABLE              = 0x200
    NOT_REFERENCED                = 0x201
    BUSY                          = 0x203
    ENDSTOP_REACHED               = 0x300
    FOLLOWING_ERROR_LIMIT_REACHED = 0x301
    REFERENCING_FAILED            = 0x320
    DRIVER_FAILED                 = 0x500
    CONNECT_FAILED                = 0x501
    NOT_CONNECTED                 = 0x502
    CONTROLLER_CONFIGURATION      = 0x503
    COMMUNICATION_FAILED          = 0x504
    INVALID_META_PROPERTY         = 0x021
    NOT_ASSEMBLED                 = 0x600
    INVALID_GROUP_HIERARCHY       = 0x601
    INTERNAL_GIMBAL_LOCK          = 0x602
    POSE_OUT_OF_RANGE             = 0x603
class Property(enum.IntEnum):
    MODEL_CODE                        = 0x0a02
    MODEL_NAME                        = 0x0a03
    IS_REFERENCED                     = 0x2a01
    HOLD_TIME                         = 0x2000
    MAX_SPEED_LINEAR_AXES             = 0x2010
    MAX_SPEED_ROTARY_AXES             = 0x2011
    PIEZO_MAX_CLF_LINEAR_AXES         = 0x2020
    PIEZO_MAX_CLF_ROTARY_AXES         = 0x2021
    DATA_TYPE                         = 0x0002
    NAME                              = 0x0003
    DEFAULT_VALUE                     = 0x0004
    UNIT                              = 0x0005
    ACCESS                            = 0x0006
    OBJECT_TYPE                       = 0x0100
    PROPERTY_KEYS                     = 0x0110
    DEVICE_CLASS_CODE                 = 0x0a00
    DEVICE_CLASS_NAME                 = 0x0a01
    ACTUATOR_MODE                     = 0x2030
    ACCELERATION_LINEAR_AXES          = 0x2012
    ACCELERATION_ROTARY_AXES          = 0x2013
    FOLLOWING_ERROR_LIMIT_LINEAR_AXES = 0x20a0
    FOLLOWING_ERROR_LIMIT_ROTARY_AXES = 0x20a1
    REF_SPEED_LINEAR_AXES             = 0x2040
    REF_SPEED_ROTARY_AXES             = 0x2041
    REF_PIEZO_FREQUENCY_LINEAR_AXES   = 0x2042
    REF_PIEZO_FREQUENCY_ROTARY_AXES   = 0x2043
    IS_CONNECTED                      = 0x2a00
    ROTATION_ORDER                    = 0x3000
    AUTO_ROT_ORDER_FRAME_CONVERSION   = 0x3001
    POSE_TYPE                         = 0x3010
    INTERNAL_GIMBAL_LOCK_CHECK        = 0x3011
    MOVE_GROUP_TYPE                   = 0x3020
    PIVOT_IS_ENABLED                  = 0x3021
    FRAME_COUNT                       = 0x3030
    BASE_FRAME_GROUP_INDEX            = 0x3040
    BASE_FRAME_IS_ABSOLUTE            = 0x3041
    BASE_FRAME_IS_ENABLED             = 0x3042
    VERSION_STRING                    = 0xf001
    LOGGING_ENABLED                   = 0xf010
    MODEL_CODES                       = 0xf100
class Global(enum.IntEnum):
    FALSE = 0
    TRUE = 1
    INFINITE = -1
    NO_HANDLE = 0
    LIBRARY_HANDLE = 1
    PROPERTY_NAME_MAX_LENGTH = 128
    OPTIONS_STRING_MAX_LENGTH = 1024
FALSE = Global.FALSE
TRUE = Global.TRUE
INFINITE = Global.INFINITE
NO_HANDLE = Global.NO_HANDLE
LIBRARY_HANDLE = Global.LIBRARY_HANDLE
PROPERTY_NAME_MAX_LENGTH = Global.PROPERTY_NAME_MAX_LENGTH
OPTIONS_STRING_MAX_LENGTH = Global.OPTIONS_STRING_MAX_LENGTH
class EventType(enum.IntEnum):
    MOVEMENT_FINISHED = 0x1
class DataType(enum.IntEnum):
    ARRAY_BIT      = 0x100
    BASE_TYPE_MASK = 0x0ff
    NONE           = 0x000
    BOOL           = 0x001
    INT32          = 0x002
    UINT32         = 0x003
    INT64          = 0x004
    UINT64         = 0x005
    DOUBLE         = 0x007
    STRING         = 0x010
    BOOL_ARRAY     = 0x101
    INT32_ARRAY    = 0x102
    UINT32_ARRAY   = 0x103
    INT64_ARRAY    = 0x104
    UINT64_ARRAY   = 0x105
    DOUBLE_ARRAY   = 0x107
class Unit(enum.IntEnum):
    NONE                      = 0x0000
    PERCENT                   = 0x0001
    METRE                     = 0x0002
    DEGREE                    = 0x0003
    SECOND                    = 0x0004
    HERTZ                     = 0x0005
    KILOGRAM                  = 0x0006
    MILLISECONDS              = 0x0100
    METRE_PER_SECOND          = 0x0200
    DEGREE_PER_SECOND         = 0x0201
    METRE_PER_SECOND_SQUARED  = 0x0202
    DEGREE_PER_SECOND_SQUARED = 0x0203
    BOOL                      = 0x0a00
    DIRECTION                 = 0x0a01
    SPECIAL                   = 0xf000
class Direction(enum.IntEnum):
    NEGATIVE = 0x1
    POSITIVE = 0x2
class ActuatorMode(enum.IntEnum):
    NORMAL        = 0x0
    QUIET         = 0x1
    LOW_VIBRATION = 0x2
class RotationOrder(enum.IntEnum):
    XYZ = 0x0
    YXZ = 0x1
    XZY = 0x2
    ZXY = 0x3
    ZYX = 0x4
    YZX = 0x5
class PoseType(enum.IntEnum):
    UNIQUE      = 0x0
    SEMI_UNIQUE = 0x1
    POSE        = 0x2
class FrameType(enum.IntEnum):
    NORMAL   = 0x0
    ABSOLUTE = 0x1
    RELATIVE = 0x2
class MoveGroupType(enum.IntEnum):
    ABSOLUTE = 0x1
    RELATIVE = 0x2
import platform
__initBindings("SmarActMC.dll" if platform.system() == "Windows" else ("lib" + "SmarActMC".lower() + ".so"))
__all__ = ["api_version", "apigen_version", "Error", "Vec3", "Pose", "Event", "GetResultInfo", "FindControllers", "Open", "Close", "Reference", "Move", "WaitForEvent", "Stop", "Cancel", "GetPose", "SetPivot", "GetPivot", "SetProperty_i32", "SetProperty_f64", "GetProperty_i32", "GetProperty_f64", "GetProperty_s", "GetProperty_i32_a", "GetPropertyKey", "AddFrame", "EditFrame", "RemoveFrame", "SetCurrentPoseAsZero", "GetFrame", "TransPose", "TransPoseInv", "TransPoint", "TransPointInv", "Calibrate", "ApiVersion", "ErrorCode", "Property", "FALSE", "TRUE", "INFINITE", "NO_HANDLE", "LIBRARY_HANDLE", "PROPERTY_NAME_MAX_LENGTH", "OPTIONS_STRING_MAX_LENGTH", "EventType", "DataType", "Unit", "Direction", "ActuatorMode", "RotationOrder", "PoseType", "FrameType", "MoveGroupType"]
