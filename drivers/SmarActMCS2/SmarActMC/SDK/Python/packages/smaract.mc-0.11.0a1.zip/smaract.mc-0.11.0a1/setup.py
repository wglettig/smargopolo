from setuptools import find_namespace_packages
from setuptools import setup
from distutils.log import warn
from setuptools.command.upload import upload as OrigUploader
class FakeUploader(OrigUploader):
    description = "Fake uploader telling you uploading is forbidden"
    user_options = []
    def initialize_options(self):
        pass
    def run(self):
        warn("You are not allowed to upload this package")
setup(
    name="smaract.mc",
    version="0.11.0alpha1",
    packages=find_namespace_packages(include=["smaract.mc"]),
    description="SmarAct Motion Control Python API",
    url="https://www.smaract.com",
    maintainer="SmarAct GmbH",
    install_requires=("cffi"),
    license="SmarAct EULA",
    entry_points = {"distutils.commands": ["upload = FakeUploader"]}
)
