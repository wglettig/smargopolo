#######################################################################
# Copyright (c) 2020 SmarAct GmbH
#
# THIS  SOFTWARE, DOCUMENTS, FILES AND INFORMATION ARE PROVIDED 'AS IS'
# WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
# BUT  NOT  LIMITED  TO, THE  IMPLIED  WARRANTIES  OF MERCHANTABILITY,
# FITNESS FOR A PURPOSE, OR THE WARRANTY OF NON - INFRINGEMENT.
# THE  ENTIRE  RISK  ARISING OUT OF USE OR PERFORMANCE OF THIS SOFTWARE
# REMAINS WITH YOU.
# IN  NO  EVENT  SHALL  THE  SMARACT  GMBH  BE  LIABLE  FOR ANY DIRECT,
# INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL OR OTHER DAMAGES ARISING
# OUT OF THE USE OR INABILITY TO USE THIS SOFTWARE.
#
# Generated on 2020-05-18 17:14 +0200
#

"""
Python bindings for SmarActMC
(C) SmarAct GmbH
Refer to the SmarAct EULA for licensing
SmarAct Motion Control Python API
"""

from cffi import FFI
import enum
import sys
assert sys.version_info >= (3, 4), "Python v3.4 or higher is required"
apigen_version = (1, 3, 5)
api_version = (0, 11, 0)
def __initBindings(libName):
    global ffi, lib
    ffi = FFI()
    ffi.cdef("""
typedef int int32_t;
struct SA_MC_Vec3{ double x; double y; double z;};
typedef struct SA_MC_Vec3 SA_MC_Vec3;
struct SA_MC_Pose{ double x; double y; double z; double rx; double ry; double rz;};
typedef struct SA_MC_Pose SA_MC_Pose;
typedef unsigned long long size_t;
typedef int32_t SA_MC_Result;
typedef unsigned int uint32_t;
typedef unsigned char uint8_t;
typedef long long int64_t;
struct SA_MC_Event{ uint32_t type; uint8_t unused[28]; union { int32_t i32; int64_t i64; uint8_t reserved[32];};};
typedef struct SA_MC_Event SA_MC_Event;
typedef uint32_t SA_MC_PropertyKey;
typedef uint32_t SA_MC_Handle;
SA_MC_Result SA_MC_GetResultInfo(SA_MC_Result resultCode, char const **info);
SA_MC_Result SA_MC_FindControllers(char const *options, char *outBuffer, size_t *bufferSize);
SA_MC_Result SA_MC_Open(SA_MC_Handle *outHandle, char const *options);
SA_MC_Result SA_MC_Close(SA_MC_Handle handle);
SA_MC_Result SA_MC_Reference(SA_MC_Handle handle);
SA_MC_Result SA_MC_Move(SA_MC_Handle handle, SA_MC_Pose const *pose);
SA_MC_Result SA_MC_WaitForEvent(SA_MC_Handle handle, SA_MC_Event *outEvent, int32_t timeout);
SA_MC_Result SA_MC_Stop(SA_MC_Handle handle);
SA_MC_Result SA_MC_Cancel(SA_MC_Handle handle);
SA_MC_Result SA_MC_GetPose(SA_MC_Handle handle, SA_MC_Pose *pose);
SA_MC_Result SA_MC_SetPivot(SA_MC_Handle handle, SA_MC_Vec3 const *pivot);
SA_MC_Result SA_MC_GetPivot(SA_MC_Handle handle, SA_MC_Vec3 *pivot);
SA_MC_Result SA_MC_SetProperty_i32(SA_MC_Handle handle, SA_MC_PropertyKey pkey, int32_t value);
SA_MC_Result SA_MC_SetProperty_f64(SA_MC_Handle handle, SA_MC_PropertyKey pkey, double value);
SA_MC_Result SA_MC_GetProperty_i32(SA_MC_Handle handle, SA_MC_PropertyKey pkey, int32_t *value);
SA_MC_Result SA_MC_GetProperty_f64(SA_MC_Handle handle, SA_MC_PropertyKey pkey, double *value);
SA_MC_Result SA_MC_GetProperty_s(SA_MC_Handle handle, SA_MC_PropertyKey pkey, char *outBuffer, size_t *bufferSize);
""")
    lib = ffi.dlopen(libName)

class Error(Exception):
    def __init__(self, func, code, arguments):
        self.func = func
        self.code = code
        self.arguments = arguments
    def __str__(self):
        return "{} returned {} with arguments {}".format(self.func, self.code, self.arguments)
class Vec3:
    """
    Members:
     - x
     - y
     - z
    
    """
    __slots__ = ['x', 'y', 'z']
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z
    def asFFI(self):
        return ffi.new("struct SA_MC_Vec3 *", {'x': self.x, 'y': self.y, 'z': self.z})
class Pose:
    """
    Members:
     - x:  Translation parallel to the X axis [m] 
     - y:  Translation parallel to the Y axis [m] 
     - z:  Translation parallel to the Z axis [m] 
     - rx:  Rotation around the X axis in [deg]    
     - ry:  Rotation around the Y axis in [deg]    
     - rz:  Rotation around the Z axis in [deg]    
    
    """
    __slots__ = ['x', 'y', 'z', 'rx', 'ry', 'rz']
    def __init__(self, x, y, z, rx, ry, rz):
        self.x = x
        self.y = y
        self.z = z
        self.rx = rx
        self.ry = ry
        self.rz = rz
    def asFFI(self):
        return ffi.new("struct SA_MC_Pose *", {'x': self.x, 'y': self.y, 'z': self.z, 'rx': self.rx, 'ry': self.ry, 'rz': self.rz})
class Event:
    def __init__(self, inst):
        self.inst = inst
    def asFFI(self):
        return self.inst
    def __getattr__(self, attr):
        return getattr(self.inst, attr)
def GetResultInfo(resultCode):
    """
    Parameters:
     - resultCode: The result code.
    
    Return value(s):
     - info: A pointer to a C string.
    """
    local_0 = ffi.new("char const **")
    local_1 = lib.SA_MC_GetResultInfo(resultCode, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("GetResultInfo", local_1, {"resultCode": resultCode})
    return ffi.string(local_0[0]).decode()
def FindControllers(options = "", bufferSize = 256):
    """
    Parameters:
     - options = "": Reserved for now.
     - bufferSize = 256: Pass the size of the provided buffer in here, on
    return, it contains the number of characters returned in outBuffer,
     or the required size, if the supplied buffer was too small.
    
    Return value(s):
     - outBuffer: The buffer for writing the result string into. The
    locators of the found controllers are separated by by a newline
    character.
    """
    local_0 = ffi.new("char []", bufferSize)
    local_1 = ffi.new("size_t *", bufferSize)
    local_2 = lib.SA_MC_FindControllers(options.encode(), local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("FindControllers", local_2, {"options": options})
    return ffi.string(local_0, local_1[0]).decode()
def Open(options):
    """
    Parameters:
     - options: A list of options. each option must be defined on a new
    line. the format is  "[option value][option value]..."    possible
    options are: model   The device model code locator The locator of
    the axis controller. E.g. "network:192.168.1.200:5000" for network
    controllers or "usb:id:98765432" for controllers with USB
    interface. A network locator contains the IP address and the port
    of the controller. The USB locator format contains the first part
    of the MCS controller serial number.
    
    Return value(s):
     - outHandle: The generated handle is returned in *outHandle.
    """
    local_0 = ffi.new("SA_MC_Handle *")
    local_1 = lib.SA_MC_Open(local_0, options.encode())
    if local_1 != ErrorCode.NONE.value:
        raise Error("Open", local_1, {"options": options})
    return local_0[0]
def Close(handle):
    """
    Parameters:
     - handle: The device handle.
    """
    local_0 = lib.SA_MC_Close(handle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Close", local_0, {"handle": handle})
    return 
def Reference(handle):
    """
    Parameters:
     - handle: The device handle.
    """
    local_0 = lib.SA_MC_Reference(handle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Reference", local_0, {"handle": handle})
    return 
def Move(handle, pose):
    """
    Parameters:
     - handle: The device handle.
     - pose: The target pose.
    """
    local_0 = pose.asFFI()
    local_1 = lib.SA_MC_Move(handle, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("Move", local_1, {"handle": handle, "pose": pose})
    return 
def WaitForEvent(handle, timeout):
    """
    Parameters:
     - handle: The device handle.
     - timeout: Wait returns with a SA_MC_ERROR_TIMEOUT if the operations
    doesn't finish within timeout milliseconds. If timeout is
    
    Return value(s):
     - outEvent: The event data returned by the function.
    """
    local_0 = ffi.new("SA_MC_Event *")
    local_1 = lib.SA_MC_WaitForEvent(handle, local_0, timeout)
    if local_1 != ErrorCode.NONE.value:
        raise Error("WaitForEvent", local_1, {"handle": handle, "timeout": timeout})
    return Event(local_0)
def Stop(handle):
    """
    Parameters:
     - handle: The device handle.
    """
    local_0 = lib.SA_MC_Stop(handle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Stop", local_0, {"handle": handle})
    return 
def Cancel(handle):
    """
    Parameters:
     - handle: The device handle.
    """
    local_0 = lib.SA_MC_Cancel(handle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Cancel", local_0, {"handle": handle})
    return 
def GetPose(handle):
    """
    Parameters:
     - handle: The device handle.
    
    Return value(s):
     - pose: The returned pose.
    """
    local_0 = ffi.new("SA_MC_Pose *")
    local_1 = lib.SA_MC_GetPose(handle, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("GetPose", local_1, {"handle": handle})
    return Pose(local_0.x, local_0.y, local_0.z, local_0.rx, local_0.ry, local_0.rz)
def SetPivot(handle, pivot):
    """
    Parameters:
     - handle: The device handle.
     - pivot: The pivot point.
    """
    local_0 = pivot.asFFI()
    local_1 = lib.SA_MC_SetPivot(handle, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("SetPivot", local_1, {"handle": handle, "pivot": pivot})
    return 
def GetPivot(handle):
    """
    Parameters:
     - handle: The device handle.
    
    Return value(s):
     - pivot: The returned current pivot point.
    """
    local_0 = ffi.new("SA_MC_Vec3 *")
    local_1 = lib.SA_MC_GetPivot(handle, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("GetPivot", local_1, {"handle": handle})
    return Vec3(local_0.x, local_0.y, local_0.z)
def SetProperty_i32(handle, pkey, value):
    """
    Parameters:
     - handle: The device handle.
     - pkey: The property key.
     - value: The property value.
    """
    local_0 = lib.SA_MC_SetProperty_i32(handle, pkey, value)
    if local_0 != ErrorCode.NONE.value:
        raise Error("SetProperty_i32", local_0, {"handle": handle, "pkey": pkey, "value": value})
    return 
def SetProperty_f64(handle, pkey, value):
    """
    Parameters:
     - handle: The handle.
     - pkey: The property key.
     - value: The property value.
    """
    local_0 = lib.SA_MC_SetProperty_f64(handle, pkey, value)
    if local_0 != ErrorCode.NONE.value:
        raise Error("SetProperty_f64", local_0, {"handle": handle, "pkey": pkey, "value": value})
    return 
def GetProperty_i32(handle, pkey):
    """
    Parameters:
     - handle: The handle.
     - pkey: The property key.
    
    Return value(s):
     - value: The property value.
    """
    local_0 = ffi.new("int32_t *")
    local_1 = lib.SA_MC_GetProperty_i32(handle, pkey, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("GetProperty_i32", local_1, {"handle": handle, "pkey": pkey})
    return local_0[0]
def GetProperty_f64(handle, pkey):
    """
    Parameters:
     - handle: The handle.
     - pkey: The property key.
    
    Return value(s):
     - value: The property value.
    """
    local_0 = ffi.new("double *")
    local_1 = lib.SA_MC_GetProperty_f64(handle, pkey, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("GetProperty_f64", local_1, {"handle": handle, "pkey": pkey})
    return local_0[0]
def GetProperty_s(handle, pkey, bufferSize = 256):
    """
    Parameters:
     - handle: The handle.
     - pkey: The property key.
     - bufferSize = 256: In: the size of the buffer.  Out: the written
    number of characters +1 (for the string termination 0-byte)  if
    successful or the required buffer size, if not.
    
    Return value(s):
     - outBuffer: The buffer to write the string to.
    """
    local_0 = ffi.new("char []", bufferSize)
    local_1 = ffi.new("size_t *", bufferSize)
    local_2 = lib.SA_MC_GetProperty_s(handle, pkey, local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("GetProperty_s", local_2, {"handle": handle, "pkey": pkey})
    return ffi.string(local_0, local_1[0]).decode()
class ApiVersion(enum.IntEnum):
    MAJOR  = 0x0
    MINOR  = 0xb
    UPDATE = 0x0
class ErrorCode(enum.IntEnum):
    NONE                          = 0x000
    OTHER                         = 0x001
    INVALID_PARAMETER             = 0x002
    INVALID_LOCATOR               = 0x003
    INVALID_HANDLE                = 0x005
    NOT_SUPPORTED                 = 0x006
    SOFTWARE_RESOURCE_LIMIT       = 0x007
    QUERYBUFFER_SIZE              = 0x008
    WRONG_DATA_TYPE               = 0x009
    NO_ACCESS                     = 0x00a
    INVALID_PROPERTY              = 0x020
    CANCELED                      = 0x100
    TIMEOUT                       = 0x101
    POSE_UNREACHABLE              = 0x200
    NOT_REFERENCED                = 0x201
    BUSY                          = 0x203
    ENDSTOP_REACHED               = 0x300
    FOLLOWING_ERROR_LIMIT_REACHED = 0x301
    REFERENCING_FAILED            = 0x320
    DRIVER_FAILED                 = 0x500
    CONNECT_FAILED                = 0x501
    NOT_CONNECTED                 = 0x502
    CONTROLLER_CONFIGURATION      = 0x503
    COMMUNICATION_FAILED          = 0x504
class Property(enum.IntEnum):
    MODEL_CODE                = 0x0a02
    MODEL_NAME                = 0x0a03
    IS_REFERENCED             = 0x2a01
    HOLD_TIME                 = 0x2000
    MAX_SPEED_LINEAR_AXES     = 0x2010
    MAX_SPEED_ROTARY_AXES     = 0x2011
    PIEZO_MAX_CLF_LINEAR_AXES = 0x2020
    PIEZO_MAX_CLF_ROTARY_AXES = 0x2021
class Global(enum.IntEnum):
    FALSE = 0
    TRUE = 1
    INFINITE = -1
    NO_HANDLE = 0
FALSE = Global.FALSE
TRUE = Global.TRUE
INFINITE = Global.INFINITE
NO_HANDLE = Global.NO_HANDLE
class EventType(enum.IntEnum):
    MOVEMENT_FINISHED = 0x1
import platform
__initBindings("SmarActMC.dll" if platform.system() == "Windows" else ("lib" + "SmarActMC".lower() + ".so"))
__all__ = ["api_version", "apigen_version", "Error", "Vec3", "Pose", "Event", "GetResultInfo", "FindControllers", "Open", "Close", "Reference", "Move", "WaitForEvent", "Stop", "Cancel", "GetPose", "SetPivot", "GetPivot", "SetProperty_i32", "SetProperty_f64", "GetProperty_i32", "GetProperty_f64", "GetProperty_s", "ApiVersion", "ErrorCode", "Property", "FALSE", "TRUE", "INFINITE", "NO_HANDLE", "EventType"]
