#######################################################################
# Copyright (c) 2020 SmarAct GmbH
#
# THIS  SOFTWARE, DOCUMENTS, FILES AND INFORMATION ARE PROVIDED 'AS IS'
# WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
# BUT  NOT  LIMITED  TO, THE  IMPLIED  WARRANTIES  OF MERCHANTABILITY,
# FITNESS FOR A PURPOSE, OR THE WARRANTY OF NON - INFRINGEMENT.
# THE  ENTIRE  RISK  ARISING OUT OF USE OR PERFORMANCE OF THIS SOFTWARE
# REMAINS WITH YOU.
# IN  NO  EVENT  SHALL  THE  SMARACT  GMBH  BE  LIABLE  FOR ANY DIRECT,
# INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL OR OTHER DAMAGES ARISING
# OUT OF THE USE OR INABILITY TO USE THIS SOFTWARE.
#
# Generated on 2020-02-28 13:24 +0100
#

"""
Python bindings for SmarActCTL
(C) SmarAct GmbH
Refer to the SmarAct EULA for licensing
SmarActCTL Python API (Private)
"""

from cffi import FFI
import enum
import sys
assert sys.version_info >= (3, 4), "Python v3.4 or higher is required"
apigen_version = (1, 3, 3)
api_version = (1, 3, 10)
def __initBindings(libName):
    global ffi, lib
    ffi = FFI()
    ffi.cdef("""
typedef unsigned char uint8_t;
typedef unsigned int uint32_t;
typedef uint32_t SA_CTL_StreamHandle_t;
typedef uint32_t SA_CTL_TransmitHandle_t;
typedef long long int64_t;
typedef int int32_t;
typedef unsigned long long size_t;
typedef uint32_t SA_CTL_DeviceHandle_t;
typedef uint32_t SA_CTL_Result_t;
typedef struct { uint32_t idx; uint32_t type; union { int32_t i32; int64_t i64; uint8_t unused[24];};}SA_CTL_Event_t;
typedef signed char int8_t;
typedef uint8_t SA_CTL_RequestID_t;
typedef uint32_t SA_CTL_PropertyKey_t;
char const *SA_CTL_GetFullVersionString();
char const *SA_CTL_GetResultInfo(SA_CTL_Result_t result);
char const *SA_CTL_GetEventInfo(SA_CTL_Event_t const *event);
SA_CTL_Result_t SA_CTL_Open(SA_CTL_DeviceHandle_t *dHandle, char const *locator, char const *config);
SA_CTL_Result_t SA_CTL_Close(SA_CTL_DeviceHandle_t dHandle);
SA_CTL_Result_t SA_CTL_Cancel(SA_CTL_DeviceHandle_t dHandle);
SA_CTL_Result_t SA_CTL_FindDevices(char const *options, char *deviceList, size_t *deviceListLen);
SA_CTL_Result_t SA_CTL_GetProperty_i32(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_PropertyKey_t pkey, int32_t *value, size_t *ioArraySize);
SA_CTL_Result_t SA_CTL_SetProperty_i32(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_PropertyKey_t pkey, int32_t value);
SA_CTL_Result_t SA_CTL_SetPropertyArray_i32(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_PropertyKey_t pkey, int32_t const *values, size_t arraySize);
SA_CTL_Result_t SA_CTL_GetProperty_i64(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_PropertyKey_t pkey, int64_t *value, size_t *ioArraySize);
SA_CTL_Result_t SA_CTL_SetProperty_i64(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_PropertyKey_t pkey, int64_t value);
SA_CTL_Result_t SA_CTL_SetPropertyArray_i64(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_PropertyKey_t pkey, int64_t const *values, size_t arraySize);
SA_CTL_Result_t SA_CTL_GetProperty_s(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_PropertyKey_t pkey, char *value, size_t *ioArraySize);
SA_CTL_Result_t SA_CTL_SetProperty_s(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_PropertyKey_t pkey, char const *value);
SA_CTL_Result_t SA_CTL_RequestReadProperty(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_PropertyKey_t pkey, SA_CTL_RequestID_t *rID, SA_CTL_TransmitHandle_t tHandle);
SA_CTL_Result_t SA_CTL_ReadProperty_i32(SA_CTL_DeviceHandle_t dHandle, SA_CTL_RequestID_t rID, int32_t *value, size_t *ioArraySize);
SA_CTL_Result_t SA_CTL_ReadProperty_i64(SA_CTL_DeviceHandle_t dHandle, SA_CTL_RequestID_t rID, int64_t *value, size_t *ioArraySize);
SA_CTL_Result_t SA_CTL_ReadProperty_s(SA_CTL_DeviceHandle_t dHandle, SA_CTL_RequestID_t rID, char *value, size_t *ioArraySize);
SA_CTL_Result_t SA_CTL_RequestWriteProperty_i32(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_PropertyKey_t pkey, int32_t value, SA_CTL_RequestID_t *rID, SA_CTL_TransmitHandle_t tHandle);
SA_CTL_Result_t SA_CTL_RequestWriteProperty_i64(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_PropertyKey_t pkey, int64_t value, SA_CTL_RequestID_t *rID, SA_CTL_TransmitHandle_t tHandle);
SA_CTL_Result_t SA_CTL_RequestWriteProperty_s(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_PropertyKey_t pkey, char const *value, SA_CTL_RequestID_t *rID, SA_CTL_TransmitHandle_t tHandle);
SA_CTL_Result_t SA_CTL_RequestWritePropertyArray_i32(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_PropertyKey_t pkey, int32_t const *values, size_t arraySize, SA_CTL_RequestID_t *rID, SA_CTL_TransmitHandle_t tHandle);
SA_CTL_Result_t SA_CTL_RequestWritePropertyArray_i64(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_PropertyKey_t pkey, int64_t const *values, size_t arraySize, SA_CTL_RequestID_t *rID, SA_CTL_TransmitHandle_t tHandle);
SA_CTL_Result_t SA_CTL_WaitForWrite(SA_CTL_DeviceHandle_t dHandle, SA_CTL_RequestID_t rID);
SA_CTL_Result_t SA_CTL_CancelRequest(SA_CTL_DeviceHandle_t dHandle, SA_CTL_RequestID_t rID);
SA_CTL_Result_t SA_CTL_CreateOutputBuffer(SA_CTL_DeviceHandle_t dHandle, SA_CTL_TransmitHandle_t *tHandle);
SA_CTL_Result_t SA_CTL_FlushOutputBuffer(SA_CTL_DeviceHandle_t dHandle, SA_CTL_TransmitHandle_t tHandle);
SA_CTL_Result_t SA_CTL_CancelOutputBuffer(SA_CTL_DeviceHandle_t dHandle, SA_CTL_TransmitHandle_t tHandle);
SA_CTL_Result_t SA_CTL_OpenCommandGroup(SA_CTL_DeviceHandle_t dHandle, SA_CTL_TransmitHandle_t *tHandle, uint32_t triggerMode);
SA_CTL_Result_t SA_CTL_CloseCommandGroup(SA_CTL_DeviceHandle_t dHandle, SA_CTL_TransmitHandle_t tHandle);
SA_CTL_Result_t SA_CTL_CancelCommandGroup(SA_CTL_DeviceHandle_t dHandle, SA_CTL_TransmitHandle_t tHandle);
SA_CTL_Result_t SA_CTL_WaitForEvent(SA_CTL_DeviceHandle_t dHandle, SA_CTL_Event_t *event, uint32_t timeout);
SA_CTL_Result_t SA_CTL_Calibrate(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_TransmitHandle_t tHandle);
SA_CTL_Result_t SA_CTL_Reference(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_TransmitHandle_t tHandle);
SA_CTL_Result_t SA_CTL_Move(SA_CTL_DeviceHandle_t dHandle, int8_t idx, int64_t moveValue, SA_CTL_TransmitHandle_t tHandle);
SA_CTL_Result_t SA_CTL_Stop(SA_CTL_DeviceHandle_t dHandle, int8_t idx, SA_CTL_TransmitHandle_t tHandle);
SA_CTL_Result_t SA_CTL_OpenStream(SA_CTL_DeviceHandle_t dHandle, SA_CTL_StreamHandle_t *sHandle, uint32_t triggerMode);
SA_CTL_Result_t SA_CTL_StreamFrame(SA_CTL_DeviceHandle_t dHandle, SA_CTL_StreamHandle_t sHandle, uint8_t const *frameData, uint32_t frameSize);
SA_CTL_Result_t SA_CTL_CloseStream(SA_CTL_DeviceHandle_t dHandle, SA_CTL_StreamHandle_t sHandle);
SA_CTL_Result_t SA_CTL_AbortStream(SA_CTL_DeviceHandle_t dHandle, SA_CTL_StreamHandle_t sHandle);
""")
    lib = ffi.dlopen(libName)

class Error(Exception):
    def __init__(self, func, code, arguments):
        self.func = func
        self.code = code
        self.arguments = arguments
    def __str__(self):
        return "{} returned {} with arguments {}".format(self.func, self.code, self.arguments)
class Event_t:
    def __init__(self, inst):
        self.inst = inst
    def asFFI(self):
        return self.inst
    def __getattr__(self, attr):
        return getattr(self.inst, attr)
def GetFullVersionString():
    """
    Returns the version of the library as a human readable string
    """
    local_0 = lib.SA_CTL_GetFullVersionString()
    return ffi.string(local_0).decode()
def GetResultInfo(result):
    """
    Returns a human readable string for the given result code

    Parameters:
     - result: Resultcode to get the description for
    """
    local_0 = lib.SA_CTL_GetResultInfo(result)
    return ffi.string(local_0).decode()
def GetEventInfo(event):
    """
    Returns a human readable info string for the given event

    Parameters:
     - event: Event to get the description for
    """
    local_0 = event.asFFI()
    local_1 = lib.SA_CTL_GetEventInfo(local_0)
    return ffi.string(local_1).decode()
def Open(locator, config = ""):
    """
    Opens a connection to a device specified by a locator string
    
    Parameters:
     - locator: Specifies the device
     - config = "": Configuration options for the initialization
    
    Return value(s):
     - dHandle: Handle to the device. Must be passed to following function
    calls.
    """
    local_0 = ffi.new("SA_CTL_DeviceHandle_t *")
    local_1 = lib.SA_CTL_Open(local_0, locator.encode(), config.encode())
    if local_1 != ErrorCode.NONE.value:
        raise Error("Open", local_1, {"locator": locator, "config": config})
    return local_0[0]
def Close(dHandle):
    """
    Closes a previously established connection to a device

    Parameters:
     - dHandle: Handle to the device
    """
    local_0 = lib.SA_CTL_Close(dHandle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Close", local_0, {"dHandle": dHandle})
    return 
def Cancel(dHandle):
    """
    Aborts all blocking functions
    
    Parameters:
     - dHandle: Handle to the device
    """
    local_0 = lib.SA_CTL_Cancel(dHandle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Cancel", local_0, {"dHandle": dHandle})
    return 
def FindDevices(options = "", deviceListLen = 1024):
    """
    Returns a list of locator strings of available devices
    
    Parameters:
     - options = "": Options for the find procedure
     - deviceListLen = 1024: Length of the buffer to allocate
    
    Return value(s):
     - deviceList: Buffer for device locators
    """
    local_0 = ffi.new("char []", deviceListLen)
    local_1 = ffi.new("size_t *", deviceListLen)
    local_2 = lib.SA_CTL_FindDevices(options.encode(), local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("FindDevices", local_2, {"options": options})
    return ffi.string(local_0, local_1[0]).decode()
def GetProperty_i32(dHandle, idx, pkey, ioArraySize = None):
    """
    Directly returns the value of a 32-bit integer (array) property
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the addressed device, module or channel
     - pkey: Key that identifies the property
     - ioArraySize: Size of the buffer for values
    
    Return value(s):
     - value: Buffer for the read values
    """
    if ioArraySize == None:
        local_0 = ffi.new("int32_t *")
        local_1 = ffi.NULL
    else:
        local_0 = ffi.new("int32_t []", ioArraySize)
        local_1 = ffi.new("size_t *", ioArraySize)
    local_2 = lib.SA_CTL_GetProperty_i32(dHandle, idx, pkey, local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("GetProperty_i32", local_2, {"dHandle": dHandle, "idx": idx, "pkey": pkey})
    return ffi.unpack(local_0, local_1[0]) if ioArraySize != None else local_0[0]
def SetProperty_i32(dHandle, idx, pkey, value):
    """
    Directly sets the value of a 32-bit integer property
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the addressed device, module or channel
     - pkey: Key that identifies the property
     - value: Value that should be written
    """
    local_0 = lib.SA_CTL_SetProperty_i32(dHandle, idx, pkey, value)
    if local_0 != ErrorCode.NONE.value:
        raise Error("SetProperty_i32", local_0, {"dHandle": dHandle, "idx": idx, "pkey": pkey, "value": value})
    return 
def SetPropertyArray_i32(dHandle, idx, pkey, values = None):
    """
    Directly sets the value of a 32-bit integer array property
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the addressed device, module or channel
     - pkey: Key that identifies the property
     - values: Buffer containing the values to be written
    """
    if values == None:
        local_0 = ffi.NULL
    else:
        local_0 = ffi.new("int32_t const *", values)
    local_1 = len(values)
    local_2 = lib.SA_CTL_SetPropertyArray_i32(dHandle, idx, pkey, local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("SetPropertyArray_i32", local_2, {"dHandle": dHandle, "idx": idx, "pkey": pkey, "values": values})
    return 
def GetProperty_i64(dHandle, idx, pkey, ioArraySize = None):
    """
    Directly returns the value of a 64-bit integer (array) property
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the addressed device, module or channel
     - pkey: Key that identifies the property
     - ioArraySize: Size of the buffer for values
    
    Return value(s):
     - value: Buffer for the read values
    """
    if ioArraySize == None:
        local_0 = ffi.new("int64_t *")
        local_1 = ffi.NULL
    else:
        local_0 = ffi.new("int64_t []", ioArraySize)
        local_1 = ffi.new("size_t *", ioArraySize)
    local_2 = lib.SA_CTL_GetProperty_i64(dHandle, idx, pkey, local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("GetProperty_i64", local_2, {"dHandle": dHandle, "idx": idx, "pkey": pkey})
    return ffi.unpack(local_0, local_1[0]) if ioArraySize != None else local_0[0]
def SetProperty_i64(dHandle, idx, pkey, value):
    """
    Directly sets the value of a 64-bit integer property
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the addressed device, module or channel
     - pkey: Key that identifies the property
     - value: Value that should be written
    """
    local_0 = lib.SA_CTL_SetProperty_i64(dHandle, idx, pkey, value)
    if local_0 != ErrorCode.NONE.value:
        raise Error("SetProperty_i64", local_0, {"dHandle": dHandle, "idx": idx, "pkey": pkey, "value": value})
    return 
def SetPropertyArray_i64(dHandle, idx, pkey, values):
    """
    Directly sets the value of a 64-bit integer array property
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the addressed device, module or channel
     - pkey: Key that identifies the property
     - values: Buffer containing the values to be written
    """
    local_0 = len(values)
    local_1 = lib.SA_CTL_SetPropertyArray_i64(dHandle, idx, pkey, values, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("SetPropertyArray_i64", local_1, {"dHandle": dHandle, "idx": idx, "pkey": pkey, "values": values})
    return 
def GetProperty_s(dHandle, idx, pkey, ioArraySize = 64):
    """
    Directly returns the value of a string (array) property
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the addressed device, module or channel
     - pkey: Key that identifies the property
     - ioArraySize = 64: Size of the buffer for values
    
    Return value(s):
     - value: Buffer for the read values
    """
    local_0 = ffi.new("char []", ioArraySize)
    local_1 = ffi.new("size_t *", ioArraySize)
    local_2 = lib.SA_CTL_GetProperty_s(dHandle, idx, pkey, local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("GetProperty_s", local_2, {"dHandle": dHandle, "idx": idx, "pkey": pkey})
    return ffi.string(local_0, local_1[0]).decode()
def SetProperty_s(dHandle, idx, pkey, value):
    """
    Directly sets the value of a string property
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the addressed device, module or channel
     - pkey: Key that identifies the property
     - value: Value that should be written
    """
    local_0 = lib.SA_CTL_SetProperty_s(dHandle, idx, pkey, value.encode())
    if local_0 != ErrorCode.NONE.value:
        raise Error("SetProperty_s", local_0, {"dHandle": dHandle, "idx": idx, "pkey": pkey, "value": value})
    return 
def RequestReadProperty(dHandle, idx, pkey, tHandle = 0):
    """
    Requests the value of a property (non-blocking)
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the addressed device, module or channel
     - pkey: Key that identifies the property
     - tHandle = 0: Optional handle to a transmit buffer. If unused set to
    zero.
    
    Return value(s):
     - rID: Request ID
    """
    local_0 = ffi.new("SA_CTL_RequestID_t *")
    local_1 = lib.SA_CTL_RequestReadProperty(dHandle, idx, pkey, local_0, tHandle)
    if local_1 != ErrorCode.NONE.value:
        raise Error("RequestReadProperty", local_1, {"dHandle": dHandle, "idx": idx, "pkey": pkey, "tHandle": tHandle})
    return local_0[0]
def ReadProperty_i32(dHandle, rID, ioArraySize = None):
    """
    Reads a 32-bit integer property value (array) that has previously been
    requested using RequestReadProperty
    
    Parameters:
     - dHandle: Handle to the device
     - rID: Request ID
     - ioArraySize: Size of the buffer for values
    
    Return value(s):
     - value: Buffer for the read values
    """
    if ioArraySize == None:
        local_0 = ffi.new("int32_t *")
        local_1 = ffi.NULL
    else:
        local_0 = ffi.new("int32_t []", ioArraySize)
        local_1 = ffi.new("size_t *", ioArraySize)
    local_2 = lib.SA_CTL_ReadProperty_i32(dHandle, rID, local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("ReadProperty_i32", local_2, {"dHandle": dHandle, "rID": rID})
    return ffi.unpack(local_0, local_1[0]) if ioArraySize != None else local_0[0]
def ReadProperty_i64(dHandle, rID, ioArraySize = None):
    """
    Reads a 64-bit integer property value (array) that has previously been
    requested using RequestReadProperty
    
    Parameters:
     - dHandle: Handle to the device
     - rID: Request ID
     - ioArraySize: Size of the buffer for values
    
    Return value(s):
     - value: Buffer for the read values
    """
    if ioArraySize == None:
        local_0 = ffi.new("int64_t *")
        local_1 = ffi.NULL
    else:
        local_0 = ffi.new("int64_t []", ioArraySize)
        local_1 = ffi.new("size_t *", ioArraySize)
    local_2 = lib.SA_CTL_ReadProperty_i64(dHandle, rID, local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("ReadProperty_i64", local_2, {"dHandle": dHandle, "rID": rID})
    return ffi.unpack(local_0, local_1[0]) if ioArraySize != None else local_0[0]
def ReadProperty_s(dHandle, rID, ioArraySize = 64):
    """
    Reads a string property value (array) that has previously been
    requested using RequestReadProperty
    
    Parameters:
     - dHandle: Handle to the device
     - rID: Request ID
     - ioArraySize = 64: Size of the buffer for values
    
    Return value(s):
     - value: Buffer for the read values
    """
    local_0 = ffi.new("char []", ioArraySize)
    local_1 = ffi.new("size_t *", ioArraySize)
    local_2 = lib.SA_CTL_ReadProperty_s(dHandle, rID, local_0, local_1)
    if local_2 != ErrorCode.NONE.value:
        raise Error("ReadProperty_s", local_2, {"dHandle": dHandle, "rID": rID})
    return ffi.string(local_0, local_1[0]).decode()
def RequestWriteProperty_i32(dHandle, idx, pkey, value, pass_rID = True, tHandle = 0):
    """
    Requests to write the value of a 32-bit integer property (non-blocking)
    
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the addressed device, module or channel
     - pkey: Key that identifies the property
     - value: Value that should be written
     - pass_rID: Whether to pass rID to the function
     - tHandle = 0: Optional handle to a transmit buffer. If unused set to
    zero.
    
    Return value(s):
     - rID: Request ID
    """
    if pass_rID:
        local_0 = ffi.new("SA_CTL_RequestID_t *")
    else:
        local_0 = ffi.NULL
    local_1 = lib.SA_CTL_RequestWriteProperty_i32(dHandle, idx, pkey, value, local_0, tHandle)
    if local_1 != ErrorCode.NONE.value:
        raise Error("RequestWriteProperty_i32", local_1, {"dHandle": dHandle, "idx": idx, "pkey": pkey, "value": value, "tHandle": tHandle})
    return local_0[0] if pass_rID else None
def RequestWriteProperty_i64(dHandle, idx, pkey, value, pass_rID = True, tHandle = 0):
    """
    Requests to write the value of a 64-bit integer property (non-blocking)
    
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the addressed device, module or channel
     - pkey: Key that identifies the property
     - value: Value that should be written
     - pass_rID: Whether to pass rID to the function
     - tHandle = 0: Optional handle to a transmit buffer. If unused set to
    zero.
    
    Return value(s):
     - rID: Request ID
    """
    if pass_rID:
        local_0 = ffi.new("SA_CTL_RequestID_t *")
    else:
        local_0 = ffi.NULL
    local_1 = lib.SA_CTL_RequestWriteProperty_i64(dHandle, idx, pkey, value, local_0, tHandle)
    if local_1 != ErrorCode.NONE.value:
        raise Error("RequestWriteProperty_i64", local_1, {"dHandle": dHandle, "idx": idx, "pkey": pkey, "value": value, "tHandle": tHandle})
    return local_0[0] if pass_rID else None
def RequestWriteProperty_s(dHandle, idx, pkey, value, pass_rID = True, tHandle = 0):
    """
    Requests to write the value of a string property (non-blocking)
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the addressed device, module or channel
     - pkey: Key that identifies the property
     - value: Value that should be written
     - pass_rID: Whether to pass rID to the function
     - tHandle = 0: Optional handle to a transmit buffer. If unused set to
    zero.
    
    Return value(s):
     - rID: Request ID
    """
    if pass_rID:
        local_0 = ffi.new("SA_CTL_RequestID_t *")
    else:
        local_0 = ffi.NULL
    local_1 = lib.SA_CTL_RequestWriteProperty_s(dHandle, idx, pkey, value.encode(), local_0, tHandle)
    if local_1 != ErrorCode.NONE.value:
        raise Error("RequestWriteProperty_s", local_1, {"dHandle": dHandle, "idx": idx, "pkey": pkey, "value": value, "tHandle": tHandle})
    return local_0[0] if pass_rID else None
def RequestWritePropertyArray_i32(dHandle, idx, pkey, values, arraySize, pass_rID = True, tHandle = 0):
    """
    Requests to write the value of a 32-bit integer array property
    (non-blocking)
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the addressed device, module or channel
     - pkey: Key that identifies the property
     - values
     - arraySize
     - pass_rID: Whether to pass rID to the function
     - tHandle = 0: Optional handle to a transmit buffer. If unused set to
    zero.
    
    Return value(s):
     - rID: Request ID
    """
    if pass_rID:
        local_0 = ffi.new("SA_CTL_RequestID_t *")
    else:
        local_0 = ffi.NULL
    local_1 = lib.SA_CTL_RequestWritePropertyArray_i32(dHandle, idx, pkey, values, arraySize, local_0, tHandle)
    if local_1 != ErrorCode.NONE.value:
        raise Error("RequestWritePropertyArray_i32", local_1, {"dHandle": dHandle, "idx": idx, "pkey": pkey, "values": values, "arraySize": arraySize, "tHandle": tHandle})
    return local_0[0] if pass_rID else None
def RequestWritePropertyArray_i64(dHandle, idx, pkey, values, arraySize, pass_rID = True, tHandle = 0):
    """
    Requests to write the value of a 64-bit integer array property
    (non-blocking)
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the addressed device, module or channel
     - pkey: Key that identifies the property
     - values
     - arraySize
     - pass_rID: Whether to pass rID to the function
     - tHandle = 0: Optional handle to a transmit buffer. If unused set to
    zero.
    
    Return value(s):
     - rID: Request ID
    """
    if pass_rID:
        local_0 = ffi.new("SA_CTL_RequestID_t *")
    else:
        local_0 = ffi.NULL
    local_1 = lib.SA_CTL_RequestWritePropertyArray_i64(dHandle, idx, pkey, values, arraySize, local_0, tHandle)
    if local_1 != ErrorCode.NONE.value:
        raise Error("RequestWritePropertyArray_i64", local_1, {"dHandle": dHandle, "idx": idx, "pkey": pkey, "values": values, "arraySize": arraySize, "tHandle": tHandle})
    return local_0[0] if pass_rID else None
def WaitForWrite(dHandle, rID):
    """
    Returns the result of a property write access that has previously been
    requested using the data type specific RequestWriteProperty_x
    function
    
    Parameters:
     - dHandle: Handle to the device
     - rID: Request ID
    """
    local_0 = lib.SA_CTL_WaitForWrite(dHandle, rID)
    if local_0 != ErrorCode.NONE.value:
        raise Error("WaitForWrite", local_0, {"dHandle": dHandle, "rID": rID})
    return 
def CancelRequest(dHandle, rID):
    """
    Cancels a non-blocking read or write request
    
    Parameters:
     - dHandle: Handle to the device
     - rID: Request ID
    """
    local_0 = lib.SA_CTL_CancelRequest(dHandle, rID)
    if local_0 != ErrorCode.NONE.value:
        raise Error("CancelRequest", local_0, {"dHandle": dHandle, "rID": rID})
    return 
def CreateOutputBuffer(dHandle):
    """
    Opens an output buffer for delayed transmission of several commands
    
    Parameters:
     - dHandle: Handle to the device
    
    Return value(s):
     - tHandle: Handle to a transmit buffer
    """
    local_0 = ffi.new("SA_CTL_TransmitHandle_t *")
    local_1 = lib.SA_CTL_CreateOutputBuffer(dHandle, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("CreateOutputBuffer", local_1, {"dHandle": dHandle})
    return local_0[0]
def FlushOutputBuffer(dHandle, tHandle):
    """
    Parameters:
     - dHandle: Handle to the device
     - tHandle: Handle to a transmit buffer
    """
    local_0 = lib.SA_CTL_FlushOutputBuffer(dHandle, tHandle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("FlushOutputBuffer", local_0, {"dHandle": dHandle, "tHandle": tHandle})
    return 
def CancelOutputBuffer(dHandle, tHandle):
    """
    Parameters:
     - dHandle: Handle to the device
     - tHandle: Handle to a transmit buffer
    """
    local_0 = lib.SA_CTL_CancelOutputBuffer(dHandle, tHandle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("CancelOutputBuffer", local_0, {"dHandle": dHandle, "tHandle": tHandle})
    return 
def OpenCommandGroup(dHandle, triggerMode):
    """
    Opens a command group that can be used to combine multiple asynchronous
     commands into an atomic group
    
    Parameters:
     - dHandle: Handle to the device
     - triggerMode: Trigger mode for this command group
    
    Return value(s):
     - tHandle: Handle to a transmit buffer
    """
    local_0 = ffi.new("SA_CTL_TransmitHandle_t *")
    local_1 = lib.SA_CTL_OpenCommandGroup(dHandle, local_0, triggerMode)
    if local_1 != ErrorCode.NONE.value:
        raise Error("OpenCommandGroup", local_1, {"dHandle": dHandle, "triggerMode": triggerMode})
    return local_0[0]
def CloseCommandGroup(dHandle, tHandle):
    """
    Closes and eventually executes the assembled command group depending on
     the configured trigger mode
    
    Parameters:
     - dHandle: Handle to the device
     - tHandle: Handle to a transmit buffer
    """
    local_0 = lib.SA_CTL_CloseCommandGroup(dHandle, tHandle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("CloseCommandGroup", local_0, {"dHandle": dHandle, "tHandle": tHandle})
    return 
def CancelCommandGroup(dHandle, tHandle):
    """
    Discards all buffered commands and releases the associated transmit
    handle
    
    Parameters:
     - dHandle: Handle to the device
     - tHandle: Handle to a transmit buffer
    """
    local_0 = lib.SA_CTL_CancelCommandGroup(dHandle, tHandle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("CancelCommandGroup", local_0, {"dHandle": dHandle, "tHandle": tHandle})
    return 
def WaitForEvent(dHandle, timeout):
    """
    Listens to events from the device
    
    Parameters:
     - dHandle: Handle to the device
     - timeout: Maximum time to wait for an event to occur
    
    Return value(s):
     - event: Event that occurred
    """
    local_0 = ffi.new("SA_CTL_Event_t *")
    local_1 = lib.SA_CTL_WaitForEvent(dHandle, local_0, timeout)
    if local_1 != ErrorCode.NONE.value:
        raise Error("WaitForEvent", local_1, {"dHandle": dHandle, "timeout": timeout})
    return Event_t(local_0)
def Calibrate(dHandle, idx, tHandle = 0):
    """
    Starts a calibration routine for a given channel
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the channel
     - tHandle = 0: Optional handle to a transmit buffer. If unused set to
    zero.
    """
    local_0 = lib.SA_CTL_Calibrate(dHandle, idx, tHandle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Calibrate", local_0, {"dHandle": dHandle, "idx": idx, "tHandle": tHandle})
    return 
def Reference(dHandle, idx, tHandle = 0):
    """
    Starts a referencing routine for a given channel
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the channel
     - tHandle = 0: Optional handle to a transmit buffer. If unused set to
    zero.
    """
    local_0 = lib.SA_CTL_Reference(dHandle, idx, tHandle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Reference", local_0, {"dHandle": dHandle, "idx": idx, "tHandle": tHandle})
    return 
def Move(dHandle, idx, moveValue, tHandle = 0):
    """
    Instructs a positioner to move according to the current move
    configuration
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the channel
     - moveValue: The interpretation depends on the configured move mode
     - tHandle = 0: Optional handle to a transmit buffer. If unused set to
    zero.
    """
    local_0 = lib.SA_CTL_Move(dHandle, idx, moveValue, tHandle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Move", local_0, {"dHandle": dHandle, "idx": idx, "moveValue": moveValue, "tHandle": tHandle})
    return 
def Stop(dHandle, idx, tHandle = 0):
    """
    Stops any ongoing movement of the given channel
    
    Parameters:
     - dHandle: Handle to the device
     - idx: Index of the channel
     - tHandle = 0: Optional handle to a transmit buffer. If unused set to
    zero.
    """
    local_0 = lib.SA_CTL_Stop(dHandle, idx, tHandle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("Stop", local_0, {"dHandle": dHandle, "idx": idx, "tHandle": tHandle})
    return 
def OpenStream(dHandle, triggerMode):
    """
    Opens a trajectory stream to the device
    
    Parameters:
     - dHandle: Handle to the device
     - triggerMode: Trigger mode for the trajectory stream
    
    Return value(s):
     - sHandle: Stream Handle
    """
    local_0 = ffi.new("SA_CTL_StreamHandle_t *")
    local_1 = lib.SA_CTL_OpenStream(dHandle, local_0, triggerMode)
    if local_1 != ErrorCode.NONE.value:
        raise Error("OpenStream", local_1, {"dHandle": dHandle, "triggerMode": triggerMode})
    return local_0[0]
def StreamFrame(dHandle, sHandle, frameData):
    """
    Supplies the device with stream data by sending one frame per function
    call
    
    Parameters:
     - dHandle: Handle to the device
     - sHandle: Stream Handle
     - frameData: Frame data buffer
    """
    local_0 = len(frameData)
    local_1 = lib.SA_CTL_StreamFrame(dHandle, sHandle, frameData, local_0)
    if local_1 != ErrorCode.NONE.value:
        raise Error("StreamFrame", local_1, {"dHandle": dHandle, "sHandle": sHandle, "frameData": frameData})
    return 
def CloseStream(dHandle, sHandle):
    """
    Closes a trajectory stream
    
    Parameters:
     - dHandle: Handle to the device
     - sHandle: Stream Handle
    """
    local_0 = lib.SA_CTL_CloseStream(dHandle, sHandle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("CloseStream", local_0, {"dHandle": dHandle, "sHandle": sHandle})
    return 
def AbortStream(dHandle, sHandle):
    """
    Aborts a trajectory stream
    
    Parameters:
     - dHandle: Handle to the device
     - sHandle: Stream Handle
    """
    local_0 = lib.SA_CTL_AbortStream(dHandle, sHandle)
    if local_0 != ErrorCode.NONE.value:
        raise Error("AbortStream", local_0, {"dHandle": dHandle, "sHandle": sHandle})
    return 
class Global(enum.IntEnum):
    INFINITE = 4294967295
    HOLD_TIME_INFINITE = -1
    FALSE = 0
    TRUE = 1
    DISABLED = 0
    ENABLED = 1
    NON_INVERTED = 0
    INVERTED = 1
    FORWARD_DIRECTION = 0
    BACKWARD_DIRECTION = 1
    EITHER_DIRECTION = 2
    STRING_MAX_LENGTH = 63
    REQUEST_ID_MAX_COUNT = 240
INFINITE = Global.INFINITE
HOLD_TIME_INFINITE = Global.HOLD_TIME_INFINITE
FALSE = Global.FALSE
TRUE = Global.TRUE
DISABLED = Global.DISABLED
ENABLED = Global.ENABLED
NON_INVERTED = Global.NON_INVERTED
INVERTED = Global.INVERTED
FORWARD_DIRECTION = Global.FORWARD_DIRECTION
BACKWARD_DIRECTION = Global.BACKWARD_DIRECTION
EITHER_DIRECTION = Global.EITHER_DIRECTION
STRING_MAX_LENGTH = Global.STRING_MAX_LENGTH
REQUEST_ID_MAX_COUNT = Global.REQUEST_ID_MAX_COUNT
class InterfaceType(enum.IntEnum):
    USB      = 0x1
    ETHERNET = 0x2
class ChannelModuleType(enum.IntEnum):
    STICK_SLIP_PIEZO_DRIVER = 0x1
    MAGNETIC_DRIVER         = 0x2
    PIEZO_SCANNER_DRIVER    = 0x3
class EventType(enum.IntEnum):
    NONE                      = 0x0000
    MOVEMENT_FINISHED         = 0x0001
    SENSOR_STATE_CHANGED      = 0x0002
    REFERENCE_FOUND           = 0x0003
    FOLLOWING_ERR_LIMIT       = 0x0004
    HOLDING_ABORTED           = 0x0005
    POSITIONER_TYPE_CHANGED   = 0x0006
    PHASING_FINISHED          = 0x0007
    SM_STATE_CHANGED          = 0x4000
    OVER_TEMPERATURE          = 0x4001
    HIGH_VOLTAGE_OVERLOAD     = 0x4002
    POWER_SUPPLY_OVERLOAD     = 0x4002
    POWER_SUPPLY_FAILURE      = 0x4003
    FAN_FAILURE_STATE_CHANGED = 0x4004
    ADJUSTMENT_FINISHED       = 0x4010
    ADJUSTMENT_STATE_CHANGED  = 0x4011
    ADJUSTMENT_UPDATE         = 0x4012
    DIGITAL_INPUT_CHANGED     = 0x4040
    STREAM_FINISHED           = 0x8000
    STREAM_READY              = 0x8001
    STREAM_TRIGGERED          = 0x8002
    CMD_GROUP_TRIGGERED       = 0x8010
    HM_STATE_CHANGED          = 0x8020
    EMERGENCY_STOP_TRIGGERED  = 0x8030
    EXT_INPUT_TRIGGERED       = 0x8040
    BUS_RESYNC_TRIGGERED      = 0x8050
    REQUEST_READY             = 0xf000
    CONNECTION_LOST           = 0xf001
    CAPTURE_TRIGGERED         = 0x0008
    CAPTURE_FINISHED          = 0x0009
    PRE_AMP_STATE_CHANGED     = 0x0100
    CANTILEVER_STATE_CHANGED  = 0x0101
class EventParameter(enum.IntEnum):
    PARAM_DETACHED = 0
    PARAM_ATTACHED = 1
    REQ_READY_TYPE_READ = 0
    REQ_READY_TYPE_WRITE = 1
    PARAM_RESULT_MASK = 65535
    PARAM_INDEX_MASK = 16711680
    PARAM_HANDLE_MASK = 4278190080
    REQ_READY_ID_MASK = 255
    REQ_READY_TYPE_MASK = 65280
    REQ_READY_DATA_TYPE_MASK = 16711680
    REQ_READY_ARRAY_SIZE_MASK = 4278190080
    REQ_READY_PROPERTY_KEY_MASK = 18446744069414584320
class ErrorCode(enum.IntEnum):
    NONE                           = 0x0000
    UNKNOWN_COMMAND                = 0x0001
    INVALID_PACKET_SIZE            = 0x0002
    TIMEOUT                        = 0x0004
    INVALID_PROTOCOL               = 0x0005
    BUFFER_UNDERFLOW               = 0x000c
    BUFFER_OVERFLOW                = 0x000d
    INVALID_FRAME_SIZE             = 0x000e
    INVALID_PACKET                 = 0x0010
    INVALID_KEY                    = 0x0012
    INVALID_PARAMETER              = 0x0013
    INVALID_DATA_TYPE              = 0x0016
    INVALID_DATA                   = 0x0017
    HANDLE_LIMIT_REACHED           = 0x0018
    ABORTED                        = 0x0019
    INVALID_DEVICE_INDEX           = 0x0020
    INVALID_MODULE_INDEX           = 0x0021
    INVALID_CHANNEL_INDEX          = 0x0022
    PERMISSION_DENIED              = 0x0023
    COMMAND_NOT_GROUPABLE          = 0x0024
    MOVEMENT_LOCKED                = 0x0025
    SYNC_FAILED                    = 0x0026
    INVALID_ARRAY_SIZE             = 0x0027
    OVERRANGE                      = 0x0028
    INVALID_CONFIGURATION          = 0x0029
    NO_HM_PRESENT                  = 0x0100
    NO_IOM_PRESENT                 = 0x0101
    NO_SM_PRESENT                  = 0x0102
    NO_SENSOR_PRESENT              = 0x0103
    SENSOR_DISABLED                = 0x0104
    POWER_SUPPLY_DISABLED          = 0x0105
    AMPLIFIER_DISABLED             = 0x0106
    INVALID_SENSOR_MODE            = 0x0107
    INVALID_ACTUATOR_MODE          = 0x0108
    INVALID_INPUT_TRIG_MODE        = 0x0109
    INVALID_CONTROL_OPTIONS        = 0x010a
    INVALID_REFERENCE_TYPE         = 0x010b
    INVALID_ADJUSTMENT_STATE       = 0x010c
    INVALID_INFO_TYPE              = 0x010d
    NO_FULL_ACCESS                 = 0x010e
    ADJUSTMENT_FAILED              = 0x010f
    MOVEMENT_OVERRIDDEN            = 0x0110
    NOT_CALIBRATED                 = 0x0111
    NOT_REFERENCED                 = 0x0112
    NOT_ADJUSTED                   = 0x0113
    SENSOR_TYPE_NOT_SUPPORTED      = 0x0114
    CONTROL_LOOP_INPUT_DISABLED    = 0x0115
    INVALID_CONTROL_LOOP_INPUT     = 0x0116
    UNEXPECTED_SENSOR_DATA         = 0x0117
    NOT_PHASED                     = 0x0118
    POSITIONER_FAULT               = 0x0119
    DRIVER_FAULT                   = 0x011a
    POSITIONER_TYPE_NOT_SUPPORTED  = 0x011b
    POSITIONER_TYPE_NOT_IDENTIFIED = 0x011c
    POSITIONER_TYPE_NOT_WRITEABLE  = 0x011e
    INVALID_ACTUATOR_TYPE          = 0x0121
    NO_COMMUTATION_SENSOR_PRESENT  = 0x0122
    AMPLIFIER_LOCKED               = 0x0123
    BUSY_MOVING                    = 0x0150
    BUSY_CALIBRATING               = 0x0151
    BUSY_REFERENCING               = 0x0152
    BUSY_ADJUSTING                 = 0x0153
    END_STOP_REACHED               = 0x0200
    FOLLOWING_ERR_LIMIT            = 0x0201
    RANGE_LIMIT_REACHED            = 0x0202
    POSITIONER_OVERLOAD            = 0x0203
    POWER_SUPPLY_FAILURE           = 0x0205
    OVER_TEMPERATURE               = 0x0206
    POWER_SUPPLY_OVERLOAD          = 0x0208
    INVALID_STREAM_HANDLE          = 0x0300
    INVALID_STREAM_CONFIGURATION   = 0x0301
    INSUFFICIENT_FRAMES            = 0x0302
    BUSY_STREAMING                 = 0x0303
    HM_INVALID_SLOT_INDEX          = 0x0400
    HM_INVALID_CHANNEL_INDEX       = 0x0401
    HM_INVALID_GROUP_INDEX         = 0x0402
    HM_INVALID_CH_GRP_INDEX        = 0x0403
    INTERNAL_COMMUNICATION         = 0x0500
    FEATURE_NOT_SUPPORTED          = 0x7ffd
    FEATURE_NOT_IMPLEMENTED        = 0x7ffe
    DEVICE_LIMIT_REACHED           = 0xf000
    INVALID_LOCATOR                = 0xf001
    INITIALIZATION_FAILED          = 0xf002
    NOT_INITIALIZED                = 0xf003
    COMMUNICATION_FAILED           = 0xf004
    INVALID_QUERYBUFFER_SIZE       = 0xf006
    INVALID_DEVICE_HANDLE          = 0xf007
    INVALID_TRANSMIT_HANDLE        = 0xf008
    UNEXPECTED_PACKET_RECEIVED     = 0xf00f
    CANCELED                       = 0xf010
    DRIVER_FAILED                  = 0xf013
    BUFFER_LIMIT_REACHED           = 0xf016
    INVALID_PROTOCOL_VERSION       = 0xf017
    DEVICE_RESET_FAILED            = 0xf018
    BUFFER_EMPTY                   = 0xf019
    DEVICE_NOT_FOUND               = 0xf01a
    THREAD_LIMIT_REACHED           = 0xf01b
    NO_APPLICATION                 = 0xf01c
    CAPTURE_RUNNING                = 0x011f
    CAPTURE_BUFFER_EMPTY           = 0x0120
    WRITE_ACCESS_LOCKED            = 0x0124
    INTERNAL_LINK_FAILURE          = 0x0204
    AMPLIFIER_FAILURE              = 0x0207
    NO_AFM_EXT_PRESENT             = 0x0250
    NO_PRE_AMP_PRESENT             = 0x0251
    NO_CANTILEVER_PRESENT          = 0x0252
    NO_AMPLIFIER_PRESENT           = 0x0253
class DataType(enum.IntEnum):
    UINT16  = 0x03
    INT32   = 0x06
    INT64   = 0x0e
    FLOAT32 = 0x10
    FLOAT64 = 0x11
    STRING  = 0x12
    NONE    = 0xff
class BaseUnit(enum.IntEnum):
    NONE    = 0x0
    PERCENT = 0x1
    METER   = 0x2
    DEGREE  = 0x3
    SECOND  = 0x4
    HERTZ   = 0x5
class Property(enum.IntEnum):
    NUMBER_OF_CHANNELS = 34537495
    NUMBER_OF_BUS_MODULES = 34537494
    INTERFACE_TYPE = 34537574
    DEVICE_STATE = 34537487
    DEVICE_SERIAL_NUMBER = 34537566
    DEVICE_NAME = 34537533
    EMERGENCY_STOP_MODE = 34537608
    DEFAULT_EMERGENCY_STOP_MODE = 34537750
    NETWORK_DISCOVER_MODE = 34537817
    NETWORK_DHCP_TIMEOUT = 34537820
    POWER_SUPPLY_ENABLED = 33751056
    NUMBER_OF_BUS_MODULE_CHANNELS = 33751063
    MODULE_TYPE = 33751142
    MODULE_STATE = 33751055
    STARTUP_OPTIONS = 167903325
    AMPLIFIER_ENABLED = 50462733
    AMPLIFIER_MODE = 50462911
    POSITIONER_CONTROL_OPTIONS = 50462813
    ACTUATOR_MODE = 50462745
    CONTROL_LOOP_INPUT = 50462744
    SENSOR_INPUT_SELECT = 50462877
    POSITIONER_TYPE = 50462780
    POSITIONER_TYPE_NAME = 50462781
    MOVE_MODE = 50659463
    CHANNEL_TYPE = 33685606
    CHANNEL_STATE = 50659343
    POSITION = 50659357
    TARGET_POSITION = 50659358
    SCAN_POSITION = 50659359
    SCAN_VELOCITY = 50659370
    HOLD_TIME = 50659368
    MOVE_VELOCITY = 50659369
    MOVE_ACCELERATION = 50659371
    MAX_CL_FREQUENCY = 50659375
    DEFAULT_MAX_CL_FREQUENCY = 50659415
    STEP_FREQUENCY = 50659374
    STEP_AMPLITUDE = 50659376
    FOLLOWING_ERROR_LIMIT = 50659413
    FOLLOWING_ERROR = 50462805
    FOLLOWING_ERROR_MAX = 84017237
    BROADCAST_STOP_OPTIONS = 50659421
    SENSOR_POWER_MODE = 50855961
    SENSOR_POWER_SAVE_DELAY = 50856020
    POSITION_MEAN_SHIFT = 50921506
    SAFE_DIRECTION = 50921511
    CL_INPUT_SENSOR_VALUE = 50462749
    CL_INPUT_AUX_VALUE = 50462898
    TARGET_TO_ZERO_VOLTAGE_HOLD_TH = 50462905
    CH_EMERGENCY_STOP_MODE = 33685640
    LOGICAL_SCALE_OFFSET = 33816612
    LOGICAL_SCALE_INVERSION = 33816613
    RANGE_LIMIT_MIN = 33816608
    RANGE_LIMIT_MAX = 33816609
    DEFAULT_RANGE_LIMIT_MIN = 33816768
    DEFAULT_RANGE_LIMIT_MAX = 33816769
    CALIBRATION_OPTIONS = 50724957
    SIGNAL_CORRECTION_OPTIONS = 50724892
    REFERENCING_OPTIONS = 50790493
    DIST_CODE_INVERTED = 50790414
    DISTANCE_TO_REF_MARK = 50790562
    POS_MOVEMENT_TYPE = 50921535
    POS_IS_CUSTOM_TYPE = 50921537
    POS_BASE_UNIT = 50921538
    POS_BASE_RESOLUTION = 50921539
    POS_HEAD_TYPE = 50921614
    POS_REF_TYPE = 50921544
    POS_P_GAIN = 50921547
    POS_I_GAIN = 50921548
    POS_D_GAIN = 50921549
    POS_PID_SHIFT = 50921550
    POS_ANTI_WINDUP = 50921551
    POS_ESD_DIST_TH = 50921552
    POS_ESD_COUNTER_TH = 50921553
    POS_TARGET_REACHED_TH = 50921554
    POS_TARGET_HOLD_TH = 50921555
    POS_SAVE = 50921482
    POS_WRITE_PROTECTION = 50921485
    STREAM_BASE_RATE = 68091948
    STREAM_EXT_SYNC_RATE = 68091949
    STREAM_OPTIONS = 68091997
    STREAM_LOAD_MAX = 68092673
    CHANNEL_ERROR = 84017274
    CHANNEL_TEMPERATURE = 84017204
    BUS_MODULE_TEMPERATURE = 84082740
    POSITIONER_FAULT_REASON = 84017427
    MOTOR_LOAD = 84017429
    DIAG_CLOSED_LOOP_FREQUENCY_AVG = 84017198
    DIAG_CLOSED_LOOP_FREQUENCY_MAX = 84017199
    DIAG_CLF_MEASURE_TIME_BASE = 84017350
    IO_MODULE_OPTIONS = 100859997
    IO_MODULE_VOLTAGE = 100859953
    IO_MODULE_ANALOG_INPUT_RANGE = 100860064
    AUX_POSITIONER_TYPE = 134348860
    AUX_POSITIONER_TYPE_NAME = 134348861
    AUX_INPUT_SELECT = 134348824
    AUX_IO_MODULE_INPUT_INDEX = 135332010
    AUX_SENSOR_MODULE_INPUT_INDEX = 134938794
    AUX_IO_MODULE_INPUT0_VALUE = 135331840
    AUX_IO_MODULE_INPUT1_VALUE = 135331841
    AUX_SENSOR_MODULE_INPUT0_VALUE = 134938624
    AUX_SENSOR_MODULE_INPUT1_VALUE = 134938625
    AUX_DIRECTION_INVERSION = 134807566
    AUX_DIGITAL_INPUT_VALUE = 134414509
    AUX_DIGITAL_OUTPUT_VALUE = 134414510
    AUX_DIGITAL_OUTPUT_SET = 134414512
    AUX_DIGITAL_OUTPUT_CLEAR = 134414513
    AUX_ANALOG_OUTPUT_VALUE0 = 134414336
    AUX_ANALOG_OUTPUT_VALUE1 = 134414337
    THD_INPUT_SELECT = 151126040
    THD_IO_MODULE_INPUT_INDEX = 152109226
    THD_SENSOR_MODULE_INPUT_INDEX = 151716010
    THD_THRESHOLD_HIGH = 151126196
    THD_THRESHOLD_LOW = 151126197
    THD_INVERSION = 151126030
    DEV_INPUT_TRIG_SELECT = 101515421
    DEV_INPUT_TRIG_MODE = 101515399
    DEV_INPUT_TRIG_CONDITION = 101515354
    CH_INPUT_TRIG_MODE = 102039687
    CH_INPUT_TRIG_CONDITION = 102039642
    CH_OUTPUT_TRIG_MODE = 101580935
    CH_OUTPUT_TRIG_POLARITY = 101580891
    CH_OUTPUT_TRIG_PULSE_WIDTH = 101580892
    CH_POS_COMP_START_THRESHOLD = 101580888
    CH_POS_COMP_INCREMENT = 101580889
    CH_POS_COMP_DIRECTION = 101580838
    CH_POS_COMP_LIMIT_MIN = 101580832
    CH_POS_COMP_LIMIT_MAX = 101580833
    HM_STATE = 34340879
    HM_LOCK_OPTIONS = 34340995
    HM_DEFAULT_LOCK_OPTIONS = 34340996
    API_EVENT_NOTIFICATION_OPTIONS = 4027580509
    EVENT_NOTIFICATION_OPTIONS = 4027580509
    API_AUTO_RECONNECT = 4027580577
    AUTO_RECONNECT = 4027580577
    DEVICE_TYPE = 34537643
    NETWORK_CONFIG_ACTIVATE = 34537808
    NETWORK_CONFIG_DHCP = 34537809
    NETWORK_CONFIG_IP = 34537810
    NETWORK_CONFIG_GATEWAY = 34537811
    NETWORK_CONFIG_NETMASK = 34537812
    NETWORK_CONFIG_MAC = 34537813
    NETWORK_CONFIG_DHCP_IP = 34537814
    NETWORK_CONFIG_DHCP_GATEWAY = 34537815
    NETWORK_CONFIG_DHCP_NETMASK = 34537816
    SUPPORTED_FEATURES = 34537678
    ADJUSTMENT_MODE = 33947674
    ADJUSTMENT_STATE = 33947663
    ADJUSTMENT_PROGRESS = 33947911
    WORKING_DISTANCE_MIN = 33947912
    WORKING_DISTANCE_MAX = 33947913
    WORKING_RANGE_SHRINK_MODE = 33947914
    WORKING_RANGE_ACTIVATE = 33947915
    FIBER_LENGTH_HEAD = 33947791
    FIBER_LENGTH_EXTENSION = 33947792
    ANALOG_IN = 34275382
    BUS_MODULE_GLOBAL_OPTIONS = 33751227
    STEP_WIDTH = 50659420
    MAX_CL_AMPLITUDE = 50659512
    AMPLIFIER_RANGE = 51511456
    SCAN_VALUE_MIN = 50659360
    SCAN_VALUE_MAX = 50659361
    SCAN_VALUE_NEUTRAL = 50659488
    SENSOR_POWER_SAVE_CYCLE_TIME = 50856094
    SENSOR_POWER_SAVE_PULSE_WIDTH = 50856028
    PHYSICAL_SCALE_OFFSET = 33816611
    SCAN_RANGE = 50725024
    INPUT_CORRECTION_TABLE = 50725032
    OUTPUT_CORRECTION_TABLE = 50724872
    INPUT_AMPLITUDE = 50724912
    POS_ACTUATOR_TYPE = 50921534
    POS_SPEED_GRADE = 50921536
    POS_PIEZO_TYPE = 50921651
    POS_MOTOR_TYPE = 50921651
    POS_OUTPUT_MAX = 50921658
    POS_OUTPUT_CONTINUOUS = 50921666
    POS_OUTPUT_TIME_CONSTANT = 50921667
    POS_COMMUTATION_SENSOR_TYPE = 50921671
    POS_SENSOR_TYPE = 50921540
    POS_STRIPE_SIZE = 50921541
    POS_SENSOR_VOLTAGE = 50921522
    POS_REF_INVERTED = 50921542
    POS_IS_ABSOLUTE = 50921543
    POS_DIST_CODE_TYPE = 50921545
    POS_CALIB_TYPE = 50921546
    POS_CALIB_PARAM0 = 50921472
    POS_CALIB_PARAM1 = 50921473
    POS_CALIB_PARAM2 = 50921474
    POS_CALIB_PARAM3 = 50921475
    POS_CALIB_PARAM4 = 50921476
    POS_CALIB_PARAM5 = 50921477
    POS_CALIB_PARAM6 = 50921478
    POS_CALIB_PARAM7 = 50921479
    POS_LV_P_GAIN = 50921623
    POS_LV_I_GAIN = 50921624
    POS_LV_D_GAIN = 50921625
    POS_LV_PID_SHIFT = 50921626
    POS_LV_ANTI_WINDUP = 50921627
    POS_CONTROL_OPTIONS = 50921565
    QUIET_MODE_LOW_SWITCH_FREQ = 50921728
    QUIET_MODE_HIGH_SWITCH_FREQ = 50921729
    QUIET_MODE_CNT_MAX = 50921730
    QUIET_MODE_DISTANCE = 50921731
    QUIET_MODE_FACTOR = 50921732
    TUNING_MODE = 50921497
    TUNING_ULTIMATE_FREQUENCY = 50921518
    POS_LIST_INDEX = 50987017
    POS_LIST_NUMBER_OF_POS_TYPES = 50987029
    POS_LIST_TYPE_CODE = 50987068
    POS_LIST_TYPE_NAME = 50987069
    POS_LIST_ACTUATOR_TYPE = 50987070
    POS_LIST_MOVEMENT_TYPE = 50987071
    POS_LIST_SPEED_GRADE = 50987072
    POS_LIST_PIEZO_TYPE = 50987187
    POS_LIST_MOTOR_TYPE = 50987187
    POS_LIST_OUTPUT_MAX = 50987194
    POS_LIST_OUTPUT_CONTINUOUS = 50987202
    POS_LIST_OUTPUT_TIME_CONSTANT = 50987203
    POS_LIST_IS_CUSTOM_TYPE = 50987073
    POS_LIST_BASE_UNIT = 50987074
    POS_LIST_BASE_RESOLUTION = 50987075
    POS_LIST_SENSOR_TYPE = 50987076
    POS_LIST_COMMUTATION_SENSOR_TYPE = 50987207
    POS_LIST_STRIPE_SIZE = 50987077
    POS_LIST_HEAD_TYPE = 50987150
    POS_LIST_SENSOR_VOLTAGE = 50987058
    POS_LIST_REF_INVERTED = 50987078
    POS_LIST_IS_ABSOLUTE = 50987079
    POS_LIST_REF_TYPE = 50987080
    POS_LIST_DIST_CODE_TYPE = 50987081
    POS_LIST_CALIB_TYPE = 50987082
    POS_LIST_CALIB_PARAM0 = 50987008
    POS_LIST_CALIB_PARAM1 = 50987009
    POS_LIST_CALIB_PARAM2 = 50987010
    POS_LIST_CALIB_PARAM3 = 50987011
    POS_LIST_CALIB_PARAM4 = 50987012
    POS_LIST_CALIB_PARAM5 = 50987013
    POS_LIST_CALIB_PARAM6 = 50987014
    POS_LIST_CALIB_PARAM7 = 50987015
    POS_LIST_P_GAIN = 50987083
    POS_LIST_I_GAIN = 50987084
    POS_LIST_D_GAIN = 50987085
    POS_LIST_PID_SHIFT = 50987086
    POS_LIST_ANTI_WINDUP = 50987087
    POS_LIST_LV_P_GAIN = 50987159
    POS_LIST_LV_I_GAIN = 50987160
    POS_LIST_LV_D_GAIN = 50987161
    POS_LIST_LV_PID_SHIFT = 50987162
    POS_LIST_LV_ANTI_WINDUP = 50987163
    POS_LIST_ESD_DIST_TH = 50987088
    POS_LIST_ESD_COUNTER_TH = 50987089
    POS_LIST_TARGET_REACHED_TH = 50987090
    POS_LIST_TARGET_HOLD_TH = 50987091
    POS_LIST_CONTROL_OPTIONS = 50987101
    POSID_IMAGE_TYPE = 51577020
    POSID_SERIAL = 51576926
    POSID_POS_TYPE_CODE = 51576892
    POSID_PRODUCTION_DATE = 51577022
    POSID_FCD_TYPE = 51577021
    POSID_FCD_DATA = 51576840
    POSID_SAVE = 51576842
    HM_GLOBAL_OPTIONS = 34341051
    HM_NUMBER_OF_SLOTS = 34341376
    HM_SLOT_INDEX = 34341377
    HM_SPDLVL_STEPS = 34341378
    HM_SPDLVL_STEP_AMPLITUDE = 34341379
    HM_SPDLVL_STEP_FREQUENCY = 34341380
    HM_SPDLVL_SCAN_VELOCITY = 34341381
    HM_JOYSTICK_DEADZONE = 34341382
    HM_JOYSTICK_ZERO_OFFSET = 34341383
    HM_TOUCH_MATRIX = 34341384
    HM_LINEAR_INCREMENT = 34341385
    HM_ROTARY_INCREMENT = 34341386
    HM_SLOT_VALID = 34341392
    HM_NUMBER_OF_CHANNELS = 34341393
    HM_CHANNEL_INDEX = 34341394
    HM_CHANNEL_NAME = 34341395
    HM_NUMBER_OF_GROUPS = 34341396
    HM_GROUP_INDEX = 34341397
    HM_ACTIVE_GROUP_INDEX = 34341398
    HM_NUMBER_OF_CHANNELS_IN_GROUP = 34341399
    HM_CHANNEL_GROUP_INDEX = 34341400
    HM_GROUP_NAME = 34341401
    HM_CHGRP_CHANNEL_INDEX = 34341408
    HM_CHGRP_JOYSTICK_MAP = 34341409
    HM_CHGRP_JOYSTICK_INVERSION = 34341410
    HM_CHGRP_JOYSTICK_CTRL_IN_MENU = 34341423
    HM_CHGRP_KNOB_MAP = 34341424
    HM_CHGRP_KNOB_INVERSION = 34341411
    HM_CHGRP_MOVE_MODE = 34341412
    HM_CHGRP_SPEED = 34341413
    HM_CHGRP_STEPS = 34341414
    HM_CHGRP_STEP_AMPLITUDE = 34341415
    HM_CHGRP_STEP_FREQUENCY = 34341416
    HM_CHGRP_SCAN_INCR = 34341417
    HM_CHGRP_SCAN_SPEED = 34341418
    HM_CHGRP_POS_INCR = 34341419
    HM_CHGRP_VELOCITY = 34341420
    HM_CHGRP_ACCELERATION = 34341421
    HM_CHGRP_HOLD_TIME = 34341422
    HM_SCREENSHOT = 34341440
    HM_JOYSTICK_AUTO_ZERO = 34341441
    HM_TOUCH_CALIBRATION = 34341442
    HM_INPUT_TEST = 34341443
    HM_INPUT_TEST_STATE = 34341444
    HM_COLOR_STYLE = 34341445
    MAX_CHANNEL_TEMPERATURE = 84082739
    AMP_SUPPLY_VOLTAGE_1 = 84082816
    AMP_SUPPLY_VOLTAGE_2 = 84082817
    AMP_SUPPLY_VOLTAGE_3 = 84082818
    AMP_SUPPLY_CURRENT = 84082885
    POWER_SUPPLY_VOLTAGE = 84082737
    DEBUG_MODULE_TEMPERATURE = 84082827
    FAN_SPEED = 84082734
    SENSOR_DATA = 84410421
    SENSOR_DATA_LIVE = 84410550
    DIAG_OPTIONS = 84017245
    SIGNAL_QUALITY = 84410629
    REF_MARK_TEST_RESULTS = 84344840
    REF_MARK_CAPTURE_DATA = 84344849
    REF_MARK_TEST_RANGE = 84344992
    SENSOR_CORRECTION_DATA = 84410376
    SM_LINK_TEST_MODE = 84607003
    SM_LINK_ERROR_COUNT = 84606994
    SM_TRANSMIT_ERROR_COUNT = 84606995
    SM_RESTART_COUNT = 84606996
    SM_DIGITAL_INPUT_VALUE = 84607149
    SM_TEMPERATURE_INPUT_VALUE = 84607030
    HM_LINK_TEST_MODE = 84672539
    HM_LINK_ERROR_COUNT = 84672530
    DEV_TIMEOUT_TEST = 84869269
    DEV_AUTO_INCREMENT = 84869270
    NETWORK_CONFIG_BUTTON_TEST = 84869466
    NETWORK_CONFIG_BUTTON_STATE = 84869467
    DEV_ECHO = 84869283
    ECHO = 84017315
    MOTOR_I2T_SUM = 84017421
    MOTOR_I2T_LOWER_LIMIT = 84017422
    MOTOR_I2T_UPPER_LIMIT = 84017423
    MOTOR_CURRENT = 84017424
    MOTOR_CURRENT_SQUARED = 84017425
    DRIVER_FAULT_REASON = 84017426
    CH_DIAG_LOG_INTERVAL = 84017310
    SENSOR_INVERSION = 84410382
    DAC_OUTPUT = 50659329
    MOTOR_WINDING_RESISTANCE = 84017428
    IO_MODULE_TEST_BOARD_CONFIG = 101777416
    AUX_NUMBER_OF_DIGITAL_DEV_INPUTS = 135201616
    AUX_NUMBER_OF_DIGITAL_DEV_OUTPUTS = 135201617
    AUX_NUMBER_OF_DIGITAL_MOD_INPUTS = 134415184
    AUX_NUMBER_OF_DIGITAL_MOD_OUTPUTS = 134415185
    AUX_NUMBER_OF_ANALOG_MOD_INPUTS = 134415186
    AUX_NUMBER_OF_ANALOG_MOD_OUTPUTS = 134415187
    AUX_NUMBER_OF_DIGITAL_INPUTS = 134349648
    AUX_NUMBER_OF_DIGITAL_OUTPUTS = 134349649
    AUX_NUMBER_OF_ANALOG_INPUTS = 134349650
    AUX_NUMBER_OF_ANALOG_OUTPUTS = 134349651
    IM_LOG_DATA = 84869260
    HM_LOG_DATA = 84672652
    DM_LOG_DATA = 84082828
    IM_MSG_SRC_LOG_LEVEL = 84869261
    HM_MSG_SRC_LOG_LEVEL = 84672653
    DM_MSG_SRC_LOG_LEVEL = 84082829
    IM_DEFAULT_MSG_SRC_LOG_LEVEL = 84869268
    HM_DEFAULT_MSG_SRC_LOG_LEVEL = 84672660
    DM_DEFAULT_MSG_SRC_LOG_LEVEL = 84082836
    DEV_INFO_TYPE = 84869219
    DEV_INFO_AVAILABLE_TYPES = 84869220
    DEV_MODULE_ID = 84869221
    DEV_MODULE_TYPE = 84869222
    DEV_HARDWARE_VERSION_CODE = 84869215
    DEV_HARDWARE_VERSION = 84869216
    DEV_FEATURE_PERMISSIONS = 84869241
    DEV_FIRMWARE_TYPE = 84869217
    DEV_FIRMWARE_VERSION = 84869218
    DEV_FIRMWARE_VERSION_INFO = 84869276
    DEV_COMPONENT_TYPE = 84869253
    DEV_IS_SECURED = 84869258
    INFO_TYPE = 84082787
    INFO_AVAILABLE_TYPES = 84082788
    MODULE_ID = 84082789
    BUS_MODULE_TYPE = 84082790
    HARDWARE_VERSION_CODE = 84082783
    HARDWARE_VERSION = 84082784
    FEATURE_PERMISSIONS = 84082809
    FIRMWARE_TYPE = 84082785
    FIRMWARE_VERSION = 84082786
    FIRMWARE_VERSION_INFO = 84082844
    COMPONENT_TYPE = 84082821
    IS_SECURED = 84082826
    DEV_FEATURE_DATA = 84869257
    FEATURE_DATA = 84082825
    DEV_FEATURE_DISABLE = 84869388
    FEATURE_DISABLE = 84082956
    STREAM_LOAD_AVG = 68092672
    STREAM_BUFFER_SIZE = 68092038
    STREAM_BUFFER_FREE = 68092076
    BEAM_INTERRUPT_TOLERANCE = 50856081
    SM_SENSOR_SLAVE_SELECT = 34078744
    SM_SENSOR_REG_SELECT = 34078877
    SM_SENSOR_REG = 34078720
    SM_SENSOR_REG_SAVE = 34078730
    AFM_STATE = 117571599
    AFM_SWEEP_MODE = 117834752
    AFM_SWEEP_FREQU_START = 117834753
    AFM_SWEEP_FREQU_STOP = 117834754
    AFM_SWEEP_FREQU_STEP_SIZE = 117834755
    AFM_SWEEP_DURATION = 117834756
    AFM_SWEEP_AMPLITUDE = 117834757
    AFM_SHAKER_FREQUENCY = 117834758
    AFM_SHAKER_AMPLITUDE = 117834759
    AFM_LI_REF_FREQUENCY = 117833774
    AFM_LI_REF_AMPLITUDE = 117833776
    AFM_LI_FILTER_OPTIONS = 117833892
    AFM_LI_FILTER_PRESCALER = 117833893
    AFM_LI_NUMBER_OF_POINTS = 117833894
    AFM_LI_NUMBER_OF_STAGES = 117833895
    AFM_CANTILEVER_ID = 117964886
    AFM_PRE_AMP_ID = 117571670
    AFM_PRE_AMP_OPTIONS = 117833821
    AFM_PRE_AMP_GAIN = 117833896
    AFM_PRE_AMP_OFFSET = 117833897
    AFM_BRIGHTNESS_LED1 = 118554625
    AFM_BRIGHTNESS_LED2 = 118554626
    CAPTURE_BUFFER_DATA = 185860104
    CAPTURE_BUFFER_SIZE = 185860230
    CAPTURE_BUFFER_SOURCE_SELECT = 185860253
    CAPTURE_BUFFER_RATE = 185860140
    CAPTURE_BUFFER_TRIGGER_MODE = 185860292
    CAPTURE_BUFFER_MODE = 185860121
    CAPTURE_BUFFER_STATE = 185860111
    INDEX_POSITION_FORWARD = 50464000
    INDEX_POSITION_BACKWARD = 50464001
    CL_AMPLITUDE_FORWARD = 50464002
    CL_AMPLITUDE_BACKWARD = 50464003
    POSITIONER_ALIGNMENT = 50464004
    SIG_SHAPE_SLOT_INDEX = 33752576
    SIG_SHAPE_SLOT_DATA = 33752577
    SIG_SHAPE_SLOT_SIZE = 33752578
    SIG_SHAPE_SLOT_SAVE = 33752579
    SIG_SHAPE_RISING = 33687044
    SIG_SHAPE_FALLING = 33687045
    SIG_SHAPE_SPEED_RISING = 33687046
    SIG_SHAPE_SPEED_FALLING = 33687047
    SIG_SHAPE_DIRECTION_RISING = 33687048
    SIG_SHAPE_DIRECTION_FALLING = 33687049
    DEV_PROG_SELECT = 34537629
    DEV_MUX_SELECT = 34537655
    DEV_BOOTLOADER_SELECT = 34537739
    DEV_HV_LOAD_SELECT = 34537488
    DEV_HV_SHORT_SELECT = 34537672
    DEV_POWER_FAULT_STATE = 34537673
    DEV_PEAK_DET_STATE = 34537674
    DEV_FREQUENCY_COUNT = 34537675
    DEV_HV_ADJUSTMENT_MODE = 34537498
    DEV_HV_MEASURE_SELECT = 34537496
    DEV_FREQUENCY_COUNT_ENABLED = 34537485
    DEV_DAC_VAL_SIN = 34537472
    DEV_DAC_VAL_COS = 34537473
    DEV_REFERENCE_ENABLED = 34537676
    DEV_SENSOR_TYPE_SELECT = 34537540
    DEV_QUAD_OUT_ENABLED = 34537677
    DEV_DAC_CALIBRATION_VALUE = 34537474
    DEV_PEAK_TEST_ENABLED = 34537607
    API_LOG_LEVEL = 4026597517
    API_DEVICE_LOGGING = 4026597535
    API_LOG_FILE_PATH = 4026597551
    API_STREAM_FRAME_FREQUENCY_LIMIT = 4027514927
    DEV_DEBUG_VALUE_1 = 17760257
    DEV_DEBUG_VALUE_2 = 17760258
    DEV_DEBUG_VALUE_3 = 17760259
    DEV_DEBUG_VALUE_4 = 17760260
    DEV_DEBUG_VALUE_5 = 17760261
    DEV_DEBUG_VALUE_6 = 17760262
    DEV_DEBUG_VALUE_7 = 17760263
    DEV_DEBUG_VALUE_8 = 17760264
    DEBUG_VALUE_1 = 16973825
    DEBUG_VALUE_2 = 16973826
    DEBUG_VALUE_3 = 16973827
    DEBUG_VALUE_4 = 16973828
    DEBUG_VALUE_5 = 16973829
    DEBUG_VALUE_6 = 16973830
    DEBUG_VALUE_7 = 16973831
    DEBUG_VALUE_8 = 16973832
    TEST_VALUE_1 = 201523201
    TEST_VALUE_2 = 201523202
    TEST_VALUE_3 = 201523203
    TEST_VALUE_4 = 201523204
    TEST_VALUE_5 = 201523205
    TEST_VALUE_6 = 201523206
    TEST_VALUE_7 = 201523207
    TEST_VALUE_8 = 201523208
class DeviceState(enum.IntEnum):
    HM_PRESENT            = 0x0001
    MOVEMENT_LOCKED       = 0x0002
    AMPLIFIER_LOCKED      = 0x0004
    INTERNAL_COMM_FAILURE = 0x0100
    IS_STREAMING          = 0x1000
class ModuleState(enum.IntEnum):
    SM_PRESENT            = 0x0001
    BOOSTER_PRESENT       = 0x0002
    ADJUSTMENT_ACTIVE     = 0x0004
    IOM_PRESENT           = 0x0008
    INTERNAL_COMM_FAILURE = 0x0100
    FAN_FAILURE           = 0x0800
    POWER_SUPPLY_FAILURE  = 0x1000
    HIGH_VOLTAGE_FAILURE  = 0x1000
    POWER_SUPPLY_OVERLOAD = 0x2000
    HIGH_VOLTAGE_OVERLOAD = 0x2000
    OVER_TEMPERATURE      = 0x4000
class ChannelState(enum.IntEnum):
    ACTIVELY_MOVING         = 0x00001
    CLOSED_LOOP_ACTIVE      = 0x00002
    CALIBRATING             = 0x00004
    REFERENCING             = 0x00008
    MOVE_DELAYED            = 0x00010
    SENSOR_PRESENT          = 0x00020
    IS_CALIBRATED           = 0x00040
    IS_REFERENCED           = 0x00080
    END_STOP_REACHED        = 0x00100
    RANGE_LIMIT_REACHED     = 0x00200
    FOLLOWING_LIMIT_REACHED = 0x00400
    MOVEMENT_FAILED         = 0x00800
    IS_STREAMING            = 0x01000
    POSITIONER_OVERLOAD     = 0x02000
    OVER_TEMPERATURE        = 0x04000
    REFERENCE_MARK          = 0x08000
    IS_PHASED               = 0x10000
    POSITIONER_FAULT        = 0x20000
    AMPLIFIER_ENABLED       = 0x40000
class HMState(enum.IntEnum):
    INTERNAL_COMM_FAILURE = 0x100
    IS_INTERNAL           = 0x200
class MoveMode(enum.IntEnum):
    CL_ABSOLUTE   = 0x0
    CL_RELATIVE   = 0x1
    SCAN_ABSOLUTE = 0x2
    SCAN_RELATIVE = 0x3
    STEP          = 0x4
class ActuatorMode(enum.IntEnum):
    NORMAL        = 0x0
    QUIET         = 0x1
    LOW_VIBRATION = 0x2
class ControlLoopInput(enum.IntEnum):
    DISABLED      = 0x0
    SENSOR        = 0x1
    POSITION      = 0x1
    AUX_IN        = 0x2
    INTERNAL_LINK = 0x3
class SensorInputSelect(enum.IntEnum):
    POSITION = 0x0
    CALC_SYS = 0x1
class AuxInputSelect(enum.IntEnum):
    IO_MODULE     = 0x0
    SENSOR_MODULE = 0x1
class THDInputSelect(enum.IntEnum):
    IO_MODULE     = 0x0
    SENSOR_MODULE = 0x1
class EmergencyStopMode(enum.IntEnum):
    NORMAL       = 0x0
    RESTRICTED   = 0x1
    AUTO_RELEASE = 0x2
class CmdGroupTriggerMode(enum.IntEnum):
    DIRECT   = 0x0
    EXTERNAL = 0x1
class StreamTriggerMode(enum.IntEnum):
    DIRECT        = 0x0
    EXTERNAL_ONCE = 0x1
    EXTERNAL_SYNC = 0x2
    EXTERNAL      = 0x3
class StreamOption(enum.IntEnum):
    INTERPOLATION_DIS = 0x1
    HOLD_LAST_FRAME   = 0x2
class StartupOption(enum.IntEnum):
    AMPLIFIER_ENABLE = 0x1
class PosControlOption(enum.IntEnum):
    ACC_REL_POS_DIS          = 0x01
    NO_SLIP                  = 0x02
    NO_SLIP_WHILE_HOLDING    = 0x04
    FORCED_SLIP_DIS          = 0x08
    STOP_ON_FOLLOWING_ERR    = 0x10
    TARGET_TO_ZERO_VOLTAGE   = 0x20
    CL_DIS_ON_FOLLOWING_ERR  = 0x40
    CL_DIS_ON_EMERGENCY_STOP = 0x80
class CalibrationOption(enum.IntEnum):
    DIRECTION             = 0x0000001
    DIST_CODE_INV_DETECT  = 0x0000002
    ASC_CALIBRATION       = 0x0000004
    REF_MARK_TEST         = 0x0000008
    LIMITED_TRAVEL_RANGE  = 0x0000100
    AUTO_TUNE             = 0x0000010
    OUTPUT_CORRECTION     = 0x0000020
    SENSOR_INV_DETECT     = 0x0000080
    NO_MOVEMENT           = 0x0008000
    SAC                   = 0x0010000
    FIND_ROUGH_MARK_DIS   = 0x0020000
    AFM_OFFSET            = 0x0040000
    AFM_FREQU_SWEEP       = 0x0080000
    PHASING               = 0x0100000
    POSITIONER_DIAGNOSTIC = 0x0200000
    INVALIDATE            = 0x1000000
class ReferencingOption(enum.IntEnum):
    START_DIR             = 0x0000001
    REVERSE_DIR           = 0x0000002
    AUTO_ZERO             = 0x0000004
    ABORT_ON_ENDSTOP      = 0x0000008
    CONTINUE_ON_REF_FOUND = 0x0000010
    STOP_ON_REF_FOUND     = 0x0000020
    INVALIDATE            = 0x1000000
class SensorPowerMode(enum.IntEnum):
    DISABLED   = 0x0
    ENABLED    = 0x1
    POWER_SAVE = 0x2
class BroadcastStopOption(enum.IntEnum):
    END_STOP_REACHED        = 0x1
    RANGE_LIMIT_REACHED     = 0x2
    FOLLOWING_LIMIT_REACHED = 0x4
class AmplifierMode(enum.IntEnum):
    DEFAULT              = 0x0
    POSITIONER_INTERLOCK = 0x1
class DeviceInputTriggerSelect(enum.IntEnum):
    IO_MODULE    = 0x0
    GLOBAL_INPUT = 0x1
class DeviceInputTriggerMode(enum.IntEnum):
    DISABLED       = 0x0
    EMERGENCY_STOP = 0x1
    STREAM         = 0x2
    CMD_GROUP      = 0x3
    EVENT          = 0x4
    AMPLIFIER_LOCK = 0x5
class ChannelInputTriggerMode(enum.IntEnum):
    DISABLED       = 0x0
    EMERGENCY_STOP = 0x1
class ChannelOutputTriggerMode(enum.IntEnum):
    CONSTANT         = 0x0
    POSITION_COMPARE = 0x1
    TARGET_REACHED   = 0x2
    ACTIVELY_MOVING  = 0x3
class TriggerCondition(enum.IntEnum):
    RISING  = 0x0
    FALLING = 0x1
    EITHER  = 0x2
class TriggerPolarity(enum.IntEnum):
    ACTIVE_LOW  = 0x0
    ACTIVE_HIGH = 0x1
class HM1LockOption(enum.IntEnum):
    GLOBAL               = 0x000001
    CONTROL              = 0x000002
    CHANNEL_MENU         = 0x000010
    GROUP_MENU           = 0x000020
    SETTINGS_MENU        = 0x000040
    LOAD_CFG_MENU        = 0x000080
    SAVE_CFG_MENU        = 0x000100
    CTRL_MODE_PARAM_MENU = 0x000200
    CHANNEL_NAME         = 0x001000
    POS_TYPE             = 0x002000
    SAFE_DIR             = 0x004000
    CALIBRATE            = 0x008000
    REFERENCE            = 0x010000
    SET_POSITION         = 0x020000
    MAX_CLF              = 0x040000
    POWER_MODE           = 0x080000
    ACTUATOR_MODE        = 0x100000
    RANGE_LIMIT          = 0x200000
    CONTROL_LOOP_INPUT   = 0x400000
class EventNotificationOption(enum.IntEnum):
    REQUEST_READY_ENABLED = 0x1
class PositionerType(enum.IntEnum):
    MODIFIED  = 0x000
    AUTOMATIC = 0x12b
    CUSTOM0   = 0x0fa
    CUSTOM1   = 0x0fb
    CUSTOM2   = 0x0fc
    CUSTOM3   = 0x0fd
class PosWriteProtection(enum.IntEnum):
    KEY = 0x534d4152
class MovementType(enum.IntEnum):
    LINEAR          = 0x0
    ROTATORY        = 0x1
    GONIOMETER      = 0x2
    TIP_TILT        = 0x3
    IRIS            = 0x4
    OSCILLATOR      = 0x5
    HIGH_LOAD_TABLE = 0x6
class IOModuleVoltage(enum.IntEnum):
    VOLTAGE_3V3 = 0x0
    VOLTAGE_5V  = 0x1
class IOModuleOption(enum.IntEnum):
    ENABLED                = 0x1
    DIGITAL_OUTPUT_ENABLED = 0x1
    EVENTS_ENABLED         = 0x2
    ANALOG_OUTPUT_ENABLED  = 0x4
class IOModuleAnalogInputRange(enum.IntEnum):
    IO_MODULE_ANALOG_INPUT_RANGE_BI_10V  = 0x0
    IO_MODULE_ANALOG_INPUT_RANGE_BI_5V   = 0x1
    IO_MODULE_ANALOG_INPUT_RANGE_BI_2_5V = 0x2
    IO_MODULE_ANALOG_INPUT_RANGE_UNI_10V = 0x3
    IO_MODULE_ANALOG_INPUT_RANGE_UNI_5V  = 0x4
class SignalCorrectionOption(enum.IntEnum):
    DAC         = 0x02
    DPEC        = 0x08
    ASC         = 0x10
    AC          = 0x01
    PEC         = 0x04
    OUTPUT_CORR = 0x20
class NetworkDiscoverMode(enum.IntEnum):
    DISABLED = 0x0
    PASSIVE  = 0x1
    ACTIVE   = 0x2
class ReferenceType(enum.IntEnum):
    NONE           = 0x0
    END_STOP       = 0x1
    SINGLE_CODED   = 0x2
    DISTANCE_CODED = 0x3
class PositionerFaultReason(enum.IntEnum):
    U_PHASE_SHORT     = 0x0001
    V_PHASE_SHORT     = 0x0002
    W_PHASE_SHORT     = 0x0004
    U_PHASE_OPEN      = 0x0008
    V_PHASE_OPEN      = 0x0010
    W_PHASE_OPEN      = 0x0020
    CURRENT_DEVIATION = 0x0040
    DRIVER_FAULT      = 0x8000
class ApiVersion(enum.IntEnum):
    VERSION_MAJOR  = 0x1
    VERSION_MINOR  = 0x3
    VERSION_UPDATE = 0xa
class BusModuleType(enum.IntEnum):
    MCS2M_I_U       = 0x0001
    MCS2M_I_E       = 0x0002
    MCS2M_H_1       = 0x0003
    MCS2M_D_3C      = 0x0004
    MCS2M_S_3C      = 0x0005
    MCS2M_S_PSC     = 0x0006
    MCS2M_IO_1      = 0x0007
    MCS2M_IO_3      = 0x0008
    MCS2M_IO_5      = 0x0009
    MCS2M_D_3SC     = 0x000a
    MCS2M_S_3SC     = 0x000b
    MCS2M_S_3SC_AFM = 0x000c
    MCS2M_IO_2      = 0x000d
    MCS2M_IO_4      = 0x000e
    MCS2M_IO_6      = 0x000f
    MCS2M_S_3C_4    = 0x0010
    MCS2M_S_3C_3    = 0x0011
    MCS2M_IO_7      = 0x0012
    MCS2M_D_3MD     = 0x0013
    MCS2M_S_US_1    = 0x0014
    MCS2M_D_1SD     = 0x0015
    MCS2M_AMP_1     = 0x0016
    MCS2M_S_UA_1    = 0x0017
    MCS2M_D_3C48    = 0x0018
    MCS2M_S_UA_2    = 0x0019
    MCS2M_IO_8      = 0x001a
    SDC3M_D_1C      = 0x1001
class AdjustmentState(enum.IntEnum):
    DISABLED      = 0x0
    MANUAL_ADJUST = 0x1
    AUTO_ADJUST   = 0x2
class AdjustmentOption(enum.IntEnum):
    SIGNAL_CONTROL_ACTIVE = 0x1
class ActuatorType(enum.IntEnum):
    S = 0x0
    L = 0x1
    F = 0x2
    A = 0x3
    M = 0x4
    D = 0x5
class SensorType(enum.IntEnum):
    NO_SENSOR = 0x0
    S_SENSOR  = 0x1
    L_SENSOR  = 0x2
    M_SENSOR  = 0x3
    I_SENSOR  = 0x4
    P_SENSOR  = 0x5
    D_SENSOR  = 0x6
    E_SENSOR  = 0x7
class DistanceCodeType(enum.IntEnum):
    TYPE_NONE  = 0x0
    TYPE_1_INC = 0x1
    TYPE_2_ALT = 0x2
class SensorVoltage(enum.IntEnum):
    VOLTAGE_3V3 = 0x0
    VOLTAGE_5V  = 0x1
class AmplifierRange(enum.IntEnum):
    M20V_100V  = 0x0
    M100V_100V = 0x1
class LinkTestMode(enum.IntEnum):
    DISABLED                   = 0x00
    STATIC                     = 0x01
    INCREMENT                  = 0x02
    LINK_TEST_BIT_INJECT_ERROR = 0x80
class HMGlobalOption(enum.IntEnum):
    HIDE_SPLASH_SCREEN = 0x1
    HIDE_ABOUT_MENU    = 0x2
class BusModuleGlobalOption(enum.IntEnum):
    FAN_DETECTION_ACTIVE = 0x1
class HMMoveMode(enum.IntEnum):
    SIMPLE      = 0x0
    ADVANCED    = 0x1
    SCAN        = 0x2
    CLOSED_LOOP = 0x3
class HMJoystick(enum.IntEnum):
    X1   = 0x0
    Y1   = 0x1
    X2   = 0x2
    Y2   = 0x3
    NONE = 0x4
class DeviceInfoType(enum.IntEnum):
    IM = 0x0
    HM = 0x1
class InfoType(enum.IntEnum):
    BM   = 0x0
    SM   = 0x1
    IOM  = 0x2
    AFM  = 0x3
    AMP  = 0x4
    SM_A = 0x5
class FeaturePermission(enum.IntEnum):
    LOW_VIBRATION         = 0x1
    ADV_SENSOR_CORRECTION = 0x2
class SupportedFeature(enum.IntEnum):
    CALIBRATE_COMMAND    = 0x01
    REFERENCE_COMMAND    = 0x02
    MOVE_COMMAND         = 0x04
    COMMAND_GROUPS       = 0x08
    TRAJECTORY_STREAMING = 0x10
    EVENTS               = 0x20
class AFMState(enum.IntEnum):
    EXTENSION_PRESENT  = 0x1
    PRE_AMP_PRESENT    = 0x2
    CANTILEVER_PRESENT = 0x4
class AFMSweepMode(enum.IntEnum):
    ONE_SHOT   = 0x0
    CONTINUOUS = 0x1
class CaptureBufferMode(enum.IntEnum):
    STOP  = 0x0
    START = 0x1
class CaptureBufferTriggerMode(enum.IntEnum):
    DIRECT   = 0x0
    MOVE_CMD = 0x1
class CaptureBufferState(enum.IntEnum):
    ACTIVE    = 0x1
    TRIGGERED = 0x2
class PositionerAlignment(enum.IntEnum):
    HORIZONTAL = 0x0
    VERTICAL   = 0x1
class PositionerControlOption(enum.IntEnum):
    POS_CTRL_OPT_BIT_FORCE_POWER_SAVE_MODE = 0x10000
class DiagnosticOption(enum.IntEnum):
    IGNORE_IS_CALIBRATED   = 0x1
    FULL_BANDWIDTH_SIN_COS = 0x2
class IOModuleTestBoardConfigOption(enum.IntEnum):
    NO_LOAD = 2147483648
class SMDigitalInput(enum.IntEnum):
    HALL_0  = 0x01
    HALL_1  = 0x02
    HALL_2  = 0x04
    LIMIT_0 = 0x08
    LIMIT_1 = 0x10
import platform
__initBindings("SmarActCTL.dll" if platform.system() == "Windows" else ("lib" + "SmarActCTL".lower() + ".so"))
__all__ = ["api_version", "apigen_version", "Error", "Event_t", "GetFullVersionString", "GetResultInfo", "GetEventInfo", "Open", "Close", "Cancel", "FindDevices", "GetProperty_i32", "SetProperty_i32", "SetPropertyArray_i32", "GetProperty_i64", "SetProperty_i64", "SetPropertyArray_i64", "GetProperty_s", "SetProperty_s", "RequestReadProperty", "ReadProperty_i32", "ReadProperty_i64", "ReadProperty_s", "RequestWriteProperty_i32", "RequestWriteProperty_i64", "RequestWriteProperty_s", "RequestWritePropertyArray_i32", "RequestWritePropertyArray_i64", "WaitForWrite", "CancelRequest", "CreateOutputBuffer", "FlushOutputBuffer", "CancelOutputBuffer", "OpenCommandGroup", "CloseCommandGroup", "CancelCommandGroup", "WaitForEvent", "Calibrate", "Reference", "Move", "Stop", "OpenStream", "StreamFrame", "CloseStream", "AbortStream", "INFINITE", "HOLD_TIME_INFINITE", "FALSE", "TRUE", "DISABLED", "ENABLED", "NON_INVERTED", "INVERTED", "FORWARD_DIRECTION", "BACKWARD_DIRECTION", "EITHER_DIRECTION", "STRING_MAX_LENGTH", "REQUEST_ID_MAX_COUNT", "InterfaceType", "ChannelModuleType", "EventType", "EventParameter", "ErrorCode", "DataType", "BaseUnit", "Property", "DeviceState", "ModuleState", "ChannelState", "HMState", "MoveMode", "ActuatorMode", "ControlLoopInput", "SensorInputSelect", "AuxInputSelect", "THDInputSelect", "EmergencyStopMode", "CmdGroupTriggerMode", "StreamTriggerMode", "StreamOption", "StartupOption", "PosControlOption", "CalibrationOption", "ReferencingOption", "SensorPowerMode", "BroadcastStopOption", "AmplifierMode", "DeviceInputTriggerSelect", "DeviceInputTriggerMode", "ChannelInputTriggerMode", "ChannelOutputTriggerMode", "TriggerCondition", "TriggerPolarity", "HM1LockOption", "EventNotificationOption", "PositionerType", "PosWriteProtection", "MovementType", "IOModuleVoltage", "IOModuleOption", "IOModuleAnalogInputRange", "SignalCorrectionOption", "NetworkDiscoverMode", "ReferenceType", "PositionerFaultReason", "ApiVersion", "BusModuleType", "AdjustmentState", "AdjustmentOption", "ActuatorType", "SensorType", "DistanceCodeType", "SensorVoltage", "AmplifierRange", "LinkTestMode", "HMGlobalOption", "BusModuleGlobalOption", "HMMoveMode", "HMJoystick", "DeviceInfoType", "InfoType", "FeaturePermission", "SupportedFeature", "AFMState", "AFMSweepMode", "CaptureBufferMode", "CaptureBufferTriggerMode", "CaptureBufferState", "PositionerAlignment", "PositionerControlOption", "DiagnosticOption", "IOModuleTestBoardConfigOption", "SMDigitalInput"]
